const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('autoDealerLicense', { deviceId:()=>ipcRenderer.invoke('license:device-id'), status:()=>ipcRenderer.invoke('license:status'), exportRequest:(name)=>ipcRenderer.invoke('license:export-request',name), importLicense:()=>ipcRenderer.invoke('license:import') });
