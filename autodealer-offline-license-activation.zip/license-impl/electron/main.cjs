const { app, BrowserWindow, shell, ipcMain, dialog } = require('electron');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const crypto = require('node:crypto');
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArSaFWSAgKYRFYAwndVFl
LlkalYQQZ6mrO5NrqAUWL3hecgti4/Unlei4qPARHN6VyiAVS2IjeN6h/9HE4HYF
zbCXeAvic9cnDEc9rsWz8vdvkUUU+xKUpBS1AouSxKmVNOPjpTTEcdjte1dorsRo
kQ743CR0Yzjb+pjYwAUc18D+QgBefZfsJsvm82HaK0O+mscUpRebOcOi9B828y/U
xtALleo6zXlzdnDOCNEknKYlxTznTzalqoDh9nWsN+oYaV0UnPfk3okRyrhY/dcu
YF99YxOrQfzFdqzy2M3EHO9BAPQ/WqmTLad12ljkHtY7hT5fDFZwgfWoWQrHO3RI
PQIDAQAB
-----END PUBLIC KEY-----
`;
const licenseDir = () => path.join(app.getPath('userData'), 'license');
const licensePath = () => path.join(licenseDir(), 'license.json');
function deviceId() {
  // Stable per-user/device fingerprint; changing Windows account/host name may require re-activation.
  const seed = [os.hostname(), os.platform(), os.arch(), process.env.USERNAME || process.env.USER || 'user'].join('|');
  return crypto.createHash('sha256').update(seed).digest('hex').toUpperCase();
}
function validateLicense(doc) {
  try {
    if (!doc || !doc.payload || !doc.signature) return { valid:false, reason:'Файл лицензии имеет неверный формат.' };
    const bytes = Buffer.from(JSON.stringify(doc.payload));
    const ok = crypto.verify('RSA-SHA256', bytes, PUBLIC_KEY, Buffer.from(doc.signature, 'base64'));
    if (!ok) return { valid:false, reason:'Цифровая подпись лицензии недействительна.' };
    if (doc.payload.deviceId !== deviceId()) return { valid:false, reason:'Лицензия выпущена для другого компьютера.' };
    if (doc.payload.expiresAt && Date.now() > Date.parse(doc.payload.expiresAt)) return { valid:false, reason:'Срок действия лицензии истёк.', license:doc.payload };
    return { valid:true, license:doc.payload };
  } catch (e) { return { valid:false, reason:'Не удалось проверить лицензию.' }; }
}
ipcMain.handle('license:device-id', () => deviceId());
ipcMain.handle('license:status', () => {
  try { return validateLicense(JSON.parse(fs.readFileSync(licensePath(),'utf8'))); }
  catch { return { valid:false, reason:'Лицензия не установлена.' }; }
});
ipcMain.handle('license:export-request', async (_e, customerName) => {
  const request = { format:'autodealer-activation-request', version:1, customerName:String(customerName||'').slice(0,200), deviceId:deviceId(), createdAt:new Date().toISOString(), product:'АвтоДилер' };
  const result = await dialog.showSaveDialog({ title:'Сохранить запрос активации', defaultPath:'autodealer-activation-request.json', filters:[{name:'Запрос активации',extensions:['json']}] });
  if (result.canceled || !result.filePath) return { canceled:true };
  fs.writeFileSync(result.filePath, JSON.stringify(request,null,2), 'utf8');
  return { ok:true, path:result.filePath };
});
ipcMain.handle('license:import', async () => {
  const result = await dialog.showOpenDialog({ title:'Выберите подписанный файл лицензии', properties:['openFile'], filters:[{name:'Файл лицензии',extensions:['json']}] });
  if (result.canceled || !result.filePaths[0]) return { canceled:true };
  try {
    const doc=JSON.parse(fs.readFileSync(result.filePaths[0],'utf8'));
    const checked=validateLicense(doc);
    if (!checked.valid) return checked;
    fs.mkdirSync(licenseDir(),{recursive:true});
    fs.writeFileSync(licensePath(), JSON.stringify(doc,null,2), {encoding:'utf8',mode:0o600});
    return checked;
  } catch { return { valid:false, reason:'Не удалось прочитать файл лицензии.' }; }
});
function createWindow() {
  const win = new BrowserWindow({ width:1440,height:920,minWidth:1024,minHeight:680,title:'АвтоДилер',backgroundColor:'#101827',autoHideMenuBar:true,webPreferences:{nodeIntegration:false,preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,sandbox:true} });
  win.loadFile(path.join(__dirname,'..','dist','index.html'));
  win.webContents.setWindowOpenHandler(({url})=>{ if(url==='about:blank')return {action:'allow'}; if(url.startsWith('https://'))shell.openExternal(url); return {action:'deny'}; });
}
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
