import React, { useEffect, useState } from 'react';
import DealerApp from './DealerApp';
import './license.css';

type LicenseState = {valid:boolean; reason?:string; license?:{customerName?:string; licenseId?:string; expiresAt?:string|null; product?:string}};
declare global { interface Window { autoDealerLicense?: { deviceId:()=>Promise<string>; status:()=>Promise<LicenseState>; exportRequest:(name:string)=>Promise<{ok?:boolean;canceled?:boolean;path?:string}>; importLicense:()=>Promise<LicenseState & {canceled?:boolean}> } } }
export default function App(){
 const [state,setState]=useState<LicenseState|null>(null); const [device,setDevice]=useState(''); const [name,setName]=useState(''); const [busy,setBusy]=useState(false); const [message,setMessage]=useState('');
 const refresh=async()=>{if(!window.autoDealerLicense){setState({valid:true,reason:'Режим разработки: проверка лицензии доступна только в приложении Windows.'});return;} const [s,d]=await Promise.all([window.autoDealerLicense.status(),window.autoDealerLicense.deviceId()]);setState(s);setDevice(d);};
 useEffect(()=>{void refresh();},[]);
 const request=async()=>{if(!window.autoDealerLicense){setMessage('Запрос лицензии создаётся в настольной версии Windows.');return;}setBusy(true);try{const r=await window.autoDealerLicense.exportRequest(name);setMessage(r.ok?'Запрос активации сохранён. Отправьте этот JSON поставщику лицензии.':'');}catch{setMessage('Не удалось сохранить запрос.');}finally{setBusy(false);}};
 const importFile=async()=>{if(!window.autoDealerLicense){setMessage('Импорт лицензии доступен в настольной версии Windows.');return;}setBusy(true);try{const s=await window.autoDealerLicense.importLicense();if(s.canceled)return;setState(s);setMessage(s.valid?'Лицензия активирована.':'Лицензия не принята: '+(s.reason||'ошибка проверки'));}catch{setMessage('Ошибка импорта лицензии.');}finally{setBusy(false);}};
 if(state===null)return <div className="lic-page">Проверка лицензии…</div>;
 if(state.valid)return <><DealerApp />{message&&<div className="lic-toast" onClick={()=>setMessage('')}>{message}　×</div>}</>;
 return <main className="lic-page"><section className="lic-card"><div className="lic-icon">🔐</div><h1>Активация «АвтоДилер»</h1><p className="lic-muted">Офлайн-лицензия, привязанная к этому компьютеру</p><div className="lic-status">● Не активирована</div><label>Код компьютера</label><textarea readOnly value={device||'Доступно в приложении Windows'} /><label>Название организации / автосервиса</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Например, Автосервис Мотор"/><button disabled={busy} onClick={()=>void request()}>Сохранить запрос активации</button><button className="lic-secondary" disabled={busy} onClick={()=>void importFile()}>Импортировать файл лицензии</button>{message&&<p className="lic-message">{message}</p>}<p className="lic-muted small">Создайте запрос и передайте его поставщику лицензии. После получения подписанного файла импортируйте его здесь. Интернет не требуется.</p></section></main>;
}
