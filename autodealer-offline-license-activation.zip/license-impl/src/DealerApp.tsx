import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Wrench,
  Users,
  Car,
  Package,
  FileText,
  DollarSign,
  TrendingUp,
  Plus,
  Search,
  Printer,
  Trash2,
  Edit,
  CheckCircle,
  Clock,
  AlertTriangle,
  Download,
  Upload,
  RefreshCw,
  X,
  Phone,
  Calendar,
  Layers,
  ChevronRight,
  ShieldCheck,
  CreditCard,
  Settings,
  Filter,
  BookOpen
} from 'lucide-react';

// --- НАЧАЛЬНЫЕ ДЕМО-ДАННЫЕ В СТИЛЕ АВТОДИЛЕР ---
const INITIAL_DATA = {
  company: {
    name: 'АвтоТехЦентр «Моторс Про»',
    inn: '7728491024',
    address: 'г. Москва, ул. Автозаводская, д. 23, корп. 2',
    phone: '+7 (495) 789-45-12',
    email: 'service@motors-pro.ru',
    master: 'Смирнов А. В.'
  },
  clients: [
    {
      id: 'c-1',
      name: 'Иванов Алексей Сергеевич',
      phone: '+7 (916) 123-45-67',
      email: 'ivanov@example.com',
      notes: 'Постоянный клиент, скидка 5%'
    },
    {
      id: 'c-2',
      name: 'Смирнова Елена Викторовна',
      phone: '+7 (926) 987-65-43',
      email: 'smirnova.e@mail.ru',
      notes: 'Требовательна к чистоте салона'
    },
    {
      id: 'c-3',
      name: 'ООО «Логистик-Групп» (представитель Петров)',
      phone: '+7 (495) 432-10-00',
      email: 'autopark@logist.ru',
      notes: 'Корпоративный клиент, оплата по безналу'
    }
  ],
  cars: [
    {
      id: 'car-1',
      clientId: 'c-1',
      brand: 'Skoda',
      model: 'Octavia A7',
      plateNumber: 'А777АА 777',
      vin: 'XW8AB4NE0KH123456',
      year: 2018,
      mileage: 114500,
      color: 'Белый'
    },
    {
      id: 'car-2',
      clientId: 'c-2',
      brand: 'Kia',
      model: 'Sportage IV',
      plateNumber: 'М456ВВ 199',
      vin: 'KNAKU814D77654321',
      year: 2020,
      mileage: 62000,
      color: 'Серый металлик'
    },
    {
      id: 'car-3',
      clientId: 'c-3',
      brand: 'Ford',
      model: 'Transit 2.2 TDI',
      plateNumber: 'Е321КХ 799',
      vin: 'WF0XXXTTFXDK98765',
      year: 2019,
      mileage: 235000,
      color: 'Белый'
    }
  ],
  parts: [
    {
      id: 'p-1',
      article: 'OC470',
      name: 'Фильтр масляный Mahle / Knecht',
      category: 'Фильтры',
      stock: 14,
      minStock: 5,
      costPrice: 650,
      sellPrice: 1150
    },
    {
      id: 'p-2',
      article: '5W40-5L-MOTUL',
      name: 'Моторное масло Motul 8100 X-cess 5W-40 (1л)',
      category: 'Масла и тех. жидкости',
      stock: 45,
      minStock: 15,
      costPrice: 900,
      sellPrice: 1500
    },
    {
      id: 'p-3',
      article: 'GDB1550',
      name: 'Колодки тормозные передние TRW/Lucas',
      category: 'Тормозная система',
      stock: 3,
      minStock: 4,
      costPrice: 2800,
      sellPrice: 4400
    },
    {
      id: 'p-4',
      article: 'SP-1011',
      name: 'Свеча зажигания NGK Laser Iridium',
      category: 'Двигатель',
      stock: 2,
      minStock: 8,
      costPrice: 850,
      sellPrice: 1400
    },
    {
      id: 'p-5',
      article: 'CLEAN-BRK',
      name: 'Очиститель тормозов и деталей 500мл',
      category: 'Автохимия',
      stock: 22,
      minStock: 10,
      costPrice: 220,
      sellPrice: 450
    }
  ],
  servicesCatalog: [
    { id: 's-1', category: 'Техническое обслуживание', name: 'Комплексное ТО (замена масла, масляного, салонного, воздушного фильтров)', normHours: 1.5, price: 3000 },
    { id: 's-2', category: 'Тормозная система', name: 'Замена тормозных колодок (передняя ось)', normHours: 1.0, price: 2000 },
    { id: 's-3', category: 'Тормозная система', name: 'Замена тормозных колодок и дисков (ось)', normHours: 1.8, price: 3600 },
    { id: 's-4', category: 'Подвеска и ходовая', name: 'Диагностика подвески комплексная на подъемнике', normHours: 0.5, price: 1000 },
    { id: 's-5', category: 'Подвеска и ходовая', name: 'Замена переднего амортизатора в сборе (пара)', normHours: 2.5, price: 5000 },
    { id: 's-6', category: 'Компьютерная диагностика', name: 'Считывание ошибок ЭБУ и сброс сервисного интервала', normHours: 0.6, price: 1500 },
    { id: 's-7', category: 'Двигатель', name: 'Замена комплекта ремня ГРМ с помпой', normHours: 4.2, price: 9500 }
  ],
  orders: [
    {
      id: 'ЗН-2026-001',
      date: '2026-10-21',
      clientId: 'c-1',
      carId: 'car-1',
      status: 'В работе',
      reason: 'Плановое ТО 115 000 км, периодический стук в районе правого переднего колеса',
      recommendations: 'Рекомендуется заменить сайлентблоки передних рычагов при следующем визите',
      mechanic: 'Кузнецов Д. (Пост 2)',
      works: [
        { id: 'w-1', name: 'Комплексное ТО (замена масла, фильтров)', normHours: 1.5, price: 3000, master: 'Кузнецов Д.', total: 3000 },
        { id: 'w-2', name: 'Диагностика подвески комплексная', normHours: 0.5, price: 1000, master: 'Кузнецов Д.', total: 1000 }
      ],
      partsUsed: [
        { id: 'pu-1', partId: 'p-1', article: 'OC470', name: 'Фильтр масляный Mahle', count: 1, price: 1150, total: 1150 },
        { id: 'pu-2', partId: 'p-2', article: '5W40-5L-MOTUL', name: 'Моторное масло Motul 8100 5W-40 (1л)', count: 4, price: 1500, total: 6000 },
        { id: 'pu-3', partId: 'p-5', article: 'CLEAN-BRK', name: 'Очиститель тормозов и деталей 500мл', count: 1, price: 450, total: 450 }
      ],
      discountPercent: 5,
      isPaid: false,
      paymentMethod: null
    },
    {
      id: 'ЗН-2026-002',
      date: '2026-10-22',
      clientId: 'c-2',
      carId: 'car-2',
      status: 'Оплачен',
      reason: 'Скрип при торможении, загорелась индикация износа колодок',
      recommendations: 'Толщина дисков в норме. Проверить задние колодки через 10 000 км.',
      mechanic: 'Васильев О. (Пост 1)',
      works: [
        { id: 'w-3', name: 'Замена тормозных колодок (передняя ось)', normHours: 1.0, price: 2000, master: 'Васильев О.', total: 2000 }
      ],
      partsUsed: [
        { id: 'pu-4', partId: 'p-3', article: 'GDB1550', name: 'Колодки тормозные передние TRW/Lucas', count: 1, price: 4400, total: 4400 },
        { id: 'pu-5', partId: 'p-5', article: 'CLEAN-BRK', name: 'Очиститель тормозов и деталей 500мл', count: 1, price: 450, total: 450 }
      ],
      discountPercent: 0,
      isPaid: true,
      paymentMethod: 'Карта'
    }
  ],
  transactions: [
    {
      id: 'tx-1',
      date: '2026-10-22 14:35',
      type: 'income',
      orderId: 'ЗН-2026-002',
      amount: 6850,
      method: 'Карта',
      comment: 'Оплата заказ-наряда ЗН-2026-002 (Смирнова Е.В.)'
    },
    {
      id: 'tx-2',
      date: '2026-10-20 11:20',
      type: 'expense',
      amount: 4500,
      category: 'Расходники цеха',
      method: 'Безналичный расчет',
      comment: 'Закупка перчаток, салфеток и ветоши'
    }
  ]
};

const ORDER_STATUSES = [
  { label: 'Принят', color: 'bg-blue-100 text-blue-800 border-blue-300' },
  { label: 'В работе', color: 'bg-amber-100 text-amber-800 border-amber-300' },
  { label: 'Ожидает запчастей', color: 'bg-purple-100 text-purple-800 border-purple-300' },
  { label: 'Готов', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
  { label: 'Закрыт', color: 'bg-gray-100 text-gray-800 border-gray-300' },
  { label: 'Оплачен', color: 'bg-green-100 text-green-800 border-green-300' }
];

export default function App() {
  // --- СОСТОЯНИЕ ХРАНИЛИЩА (LOCALSTORAGE) ---
  const [data, setData] = useState(() => {
    try {
      const saved = localStorage.getItem('autodealer_crm_data_v1');
      return saved ? JSON.parse(saved) : INITIAL_DATA;
    } catch (e) {
      console.error('Ошибка загрузки данных', e);
      return INITIAL_DATA;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('autodealer_crm_data_v1', JSON.stringify(data));
    } catch (e) {
      console.error('Не удалось сохранить данные в хранилище', e);
    }
  }, [data]);

  // Навигация
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [toastMessage, setToastMessage] = useState(null);

  // Модальные окна
  const [activeModal, setActiveModal] = useState(null); // 'orderEdit' | 'clientNew' | 'partNew' | 'serviceNew' | 'printOrder' | 'paymentModal' | 'partStockChange'
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [selectedClientId, setSelectedClientId] = useState(null);
  const [paymentReceipt, setPaymentReceipt] = useState(null);

  // Фильтры
  const [orderFilterStatus, setOrderFilterStatus] = useState('Все');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [stockSearchQuery, setStockSearchQuery] = useState('');
  const [clientSearchQuery, setClientSearchQuery] = useState('');

  const showToast = (text) => {
    setToastMessage(text);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleResetData = () => {
    if (window.confirm('Сбросить базу данных к стандартным демо-данным? Все несохраненные изменения будут перезаписаны.')) {
      setData(INITIAL_DATA);
      showToast('База данных успешно сброшена к исходным демо-данным');
    }
  };

  const handleExportData = () => {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `autodealer-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Резервная копия базы данных успешно скачана');
  };

  const handleImportData = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target.result);
        if (parsed.orders && parsed.clients && parsed.parts) {
          setData(parsed);
          showToast('База данных успешно импортирована');
        } else {
          alert('Неверный формат файла бэкапа');
        }
      } catch (err) {
        alert('Ошибка при чтении файла JSON: ' + err.message);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Расчет стоимости заказ-наряда
  const calculateOrderTotals = (order) => {
    const worksTotal = order.works.reduce((acc, w) => acc + (Number(w.total) || 0), 0);
    const partsTotal = order.partsUsed.reduce((acc, p) => acc + (Number(p.total) || 0), 0);
    const rawTotal = worksTotal + partsTotal;
    const discount = (rawTotal * (Number(order.discountPercent) || 0)) / 100;
    const finalTotal = Math.round(rawTotal - discount);
    return { worksTotal, partsTotal, rawTotal, discount, finalTotal };
  };

  // Аналитические показатели для Дашборда
  const dashboardStats = useMemo(() => {
    const activeOrders = data.orders.filter(o => o.status !== 'Закрыт' && o.status !== 'Оплачен');
    const today = new Date().toISOString().split('T')[0];

    const todayIncome = data.transactions
      .filter(t => t.type === 'income' && t.date.startsWith(today))
      .reduce((sum, t) => sum + t.amount, 0);

    const totalIncome = data.transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const paidOrdersCount = data.orders.filter(o => o.isPaid).length;
    const averageBill = paidOrdersCount > 0 ? Math.round(totalIncome / paidOrdersCount) : 0;

    const lowStockPartsCount = data.parts.filter(p => p.stock <= p.minStock).length;

    return {
      activeOrdersCount: activeOrders.length,
      todayIncome,
      totalIncome,
      averageBill,
      lowStockPartsCount,
      totalClients: data.clients.length,
      totalCars: data.cars.length
    };
  }, [data]);

  // Обработчик создания/сохранения заказ-наряда
  const handleSaveOrder = (updatedOrder) => {
    const exists = data.orders.find(o => o.id === updatedOrder.id);
    let newOrders = [];
    if (exists) {
      newOrders = data.orders.map(o => o.id === updatedOrder.id ? updatedOrder : o);
    } else {
      newOrders = [updatedOrder, ...data.orders];
    }
    setData(prev => ({ ...prev, orders: newOrders }));
    setActiveModal(null);
    showToast(`Заказ-наряд ${updatedOrder.id} успешно сохранен`);
  };

  // Оплата заказ-наряда
  const handlePayOrder = (orderId, paymentMethod) => {
    const order = data.orders.find(o => o.id === orderId);
    if (!order) return;
    const { finalTotal } = calculateOrderTotals(order);
    const client = data.clients.find(c => c.id === order.clientId);

    const updatedOrders = data.orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          isPaid: true,
          status: 'Оплачен',
          paymentMethod
        };
      }
      return o;
    });

    const paidAt = new Date();
    const transactionId = `tx-${Date.now()}`;
    const newTx = {
      id: transactionId,
      date: paidAt.toISOString().replace('T', ' ').substring(0, 16),
      type: 'income',
      orderId: order.id,
      amount: finalTotal,
      method: paymentMethod,
      comment: `Оплата заказ-наряда ${order.id} (${client ? client.name : 'Клиент'})`
    };

    setData(prev => ({
      ...prev,
      orders: updatedOrders,
      transactions: [newTx, ...prev.transactions]
    }));

    const car = data.cars.find(c => c.id === order.carId);
    setPaymentReceipt({
      receiptNo: `Ч-${String(Date.now()).slice(-8)}`,
      transactionId,
      date: paidAt.toLocaleString('ru-RU'),
      orderId: order.id,
      amount: finalTotal,
      method: paymentMethod,
      clientName: client?.name || order.clientName || 'Не указан',
      clientPhone: client?.phone || '',
      carName: car ? `${car.brand || ''} ${car.model || ''}`.trim() : (order.carName || 'Не указан'),
      plateNumber: car?.plateNumber || order.plateNumber || '',
      vin: car?.vin || order.vin || '',
      company: data.company || {},
      comment: newTx.comment
    });
    showToast(`Заказ-наряд ${order.id} оплачен на сумму ${finalTotal.toLocaleString('ru-RU')} ₽`);
    setActiveModal(null);
  };

  return (
    <div className="flex h-screen bg-slate-900 text-slate-100 font-sans antialiased overflow-hidden select-none">
      {/* Toast Уведомление */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-lg shadow-2xl flex items-center gap-3 border border-emerald-400 animate-bounce">
          <CheckCircle className="w-5 h-5 flex-shrink-0" />
          <span className="font-medium text-sm">{toastMessage}</span>
        </div>
      )}

      {/* БОКОВОЕ МЕНЮ (SIDEBAR) */}
      <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col flex-shrink-0">
        <div className="p-5 border-b border-slate-800 flex items-center gap-3">
          <div className="bg-gradient-to-tr from-amber-500 to-red-600 p-2.5 rounded-xl shadow-lg">
            <Wrench className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="font-bold text-lg tracking-wider text-slate-100 flex items-center gap-1.5">
              АВТО<span className="text-amber-500">ДИЛЕР</span>
            </div>
            <p className="text-xs text-slate-400 font-medium">Сервис Управление 2.4</p>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Аналитика и Дашборд', icon: TrendingUp },
            { id: 'orders', label: 'Заказ-наряды', icon: FileText, badge: data.orders.filter(o => o.status !== 'Закрыт' && o.status !== 'Оплачен').length },
            { id: 'clients', label: 'Клиенты и Автомобили', icon: Users },
            { id: 'car-catalog', label: 'Справочник автомобилей', icon: BookOpen },
            { id: 'inspection', label: 'Акт осмотра автомобиля', icon: Car },
            { id: 'service-contract', label: 'Договор оказания услуг', icon: FileText },
            { id: 'warehouse', label: 'Склад запчастей', icon: Package, badge: data.parts.filter(p => p.stock <= p.minStock).length, badgeColor: 'bg-amber-600' },
            { id: 'services', label: 'Каталог услуг', icon: Layers },
            { id: 'cashbox', label: 'Касса и Финансы', icon: DollarSign },
            { id: 'settings', label: 'Реквизиты и Бэкап', icon: Settings }
          ].map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-md font-semibold'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${item.badgeColor || (isActive ? 'bg-slate-900 text-amber-400' : 'bg-amber-500 text-slate-950')}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Пользователь и быстрый статус */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-amber-400 font-bold text-sm">
              МП
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-semibold text-slate-200 truncate">Мастер-Приёмщик</div>
              <div className="text-[11px] text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Пост приёмки №1
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* ОСНОВНАЯ ОБЛАСТЬ КОНТЕНТА */}
      <main className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
        {/* Верхняя информационная полоса */}
        <header className="h-14 border-b border-slate-800 bg-slate-950/40 px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-base font-semibold text-slate-100 uppercase tracking-wide">
              {currentTab === 'dashboard' && 'Главная аналитическая панель'}
              {currentTab === 'orders' && 'Журнал заказ-нарядов автосервиса'}
              {currentTab === 'clients' && 'Клиентская база и автопарк'}
              {currentTab === 'car-catalog' && 'Справочник автомобилей'}
              {currentTab === 'inspection' && 'Акт осмотра автомобиля при приёмке'}
              {currentTab === 'service-contract' && 'Договор оказания услуг по ремонту автомобиля'}
              {currentTab === 'warehouse' && 'Складской учет запасных частей и ГСМ'}
              {currentTab === 'services' && 'Справочник норм времени и тарифов'}
              {currentTab === 'cashbox' && 'Учет платежей, касса и расходы'}
              {currentTab === 'settings' && 'Настройки автотехцентра и резервное копирование'}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setSelectedOrderId(null);
                setActiveModal('orderEdit');
              }}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Новый заказ-наряд
            </button>
            <button
              onClick={() => setActiveModal('clientNew')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Users className="w-4 h-4 text-slate-400" />
              Клиент + Авто
            </button>
          </div>
        </header>

        {/* Контейнер вкладки */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-900/90">
          {currentTab === 'dashboard' && (
            <DashboardView
              stats={dashboardStats}
              orders={data.orders}
              clients={data.clients}
              cars={data.cars}
              parts={data.parts}
              calculateOrderTotals={calculateOrderTotals}
              onOpenOrder={(id) => {
                setSelectedOrderId(id);
                setActiveModal('orderEdit');
              }}
              onPrintOrder={(id) => {
                setSelectedOrderId(id);
                setActiveModal('printOrder');
              }}
              onQuickCreateOrder={() => {
                setSelectedOrderId(null);
                setActiveModal('orderEdit');
              }}
              onQuickAddPart={() => setActiveModal('partNew')}
            />
          )}

          {currentTab === 'orders' && (
            <OrdersView
              orders={data.orders}
              clients={data.clients}
              cars={data.cars}
              filterStatus={orderFilterStatus}
              setFilterStatus={setOrderFilterStatus}
              searchQuery={orderSearchQuery}
              setSearchQuery={setOrderSearchQuery}
              calculateOrderTotals={calculateOrderTotals}
              onOpenOrder={(id) => {
                setSelectedOrderId(id);
                setActiveModal('orderEdit');
              }}
              onPrintOrder={(id) => {
                setSelectedOrderId(id);
                setActiveModal('printOrder');
              }}
              onPayOrderPrompt={(id) => {
                setSelectedOrderId(id);
                setActiveModal('paymentModal');
              }}
              onDeleteOrder={(id) => {
                if (window.confirm(`Удалить заказ-наряд ${id}?`)) {
                  setData(prev => ({
                    ...prev,
                    orders: prev.orders.filter(o => o.id !== id)
                  }));
                  showToast(`Заказ-наряд ${id} удален`);
                }
              }}
              onCreateNew={() => {
                setSelectedOrderId(null);
                setActiveModal('orderEdit');
              }}
            />
          )}

          {currentTab === 'clients' && (
            <ClientsView
              clients={data.clients}
              cars={data.cars}
              orders={data.orders}
              searchQuery={clientSearchQuery}
              setSearchQuery={setClientSearchQuery}
              onAddNewClient={() => setActiveModal('clientNew')}
              onOpenOrder={(orderId) => {
                setSelectedOrderId(orderId);
                setActiveModal('orderEdit');
              }}
            />
          )}

          {currentTab === 'car-catalog' && <CarCatalogView />}

          {currentTab === 'inspection' && <VehicleInspectionView cars={data.cars} clients={data.clients} />}

          {currentTab === 'service-contract' && <ServiceContractView company={data.company} cars={data.cars} clients={data.clients} />}

          {currentTab === 'warehouse' && (
            <WarehouseView
              parts={data.parts}
              searchQuery={stockSearchQuery}
              setSearchQuery={setStockSearchQuery}
              onAddNewPart={() => setActiveModal('partNew')}
              onQuickStockUpdate={(partId, amount) => {
                setData(prev => ({
                  ...prev,
                  parts: prev.parts.map(p => {
                    if (p.id === partId) {
                      const newStock = Math.max(0, p.stock + amount);
                      return { ...p, stock: newStock };
                    }
                    return p;
                  })
                }));
                showToast('Остаток запчасти обновлен');
              }}
            />
          )}

          {currentTab === 'services' && (
            <ServicesView
              servicesCatalog={data.servicesCatalog}
              onAddNewService={() => setActiveModal('serviceNew')}
              onDeleteService={(id) => {
                if (window.confirm('Удалить услугу из каталога?')) {
                  setData(prev => ({
                    ...prev,
                    servicesCatalog: prev.servicesCatalog.filter(s => s.id !== id)
                  }));
                  showToast('Услуга удалена');
                }
              }}
            />
          )}

          {currentTab === 'cashbox' && (
            <CashboxView
              transactions={data.transactions}
              orders={data.orders}
              onAddExpense={(expense) => {
                const newTx = {
                  id: `tx-${Date.now()}`,
                  date: new Date().toISOString().replace('T', ' ').substring(0, 16),
                  type: 'expense',
                  amount: Number(expense.amount),
                  category: expense.category,
                  method: expense.method,
                  comment: expense.comment
                };
                setData(prev => ({
                  ...prev,
                  transactions: [newTx, ...prev.transactions]
                }));
                showToast('Расход успешно зафиксирован');
              }}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              company={data.company}
              onSaveCompany={(newCompany) => {
                setData(prev => ({ ...prev, company: newCompany }));
                showToast('Реквизиты автосервиса обновлены');
              }}
              onResetData={handleResetData}
              onExportData={handleExportData}
              onImportData={handleImportData}
            />
          )}
        </div>
      </main>

      {/* --- МОДАЛЬНЫЕ ОКНА --- */}

      {/* 1. Редактирование / Создание заказ-наряда */}
      {activeModal === 'orderEdit' && (
        <OrderEditModal
          orderId={selectedOrderId}
          existingOrders={data.orders}
          clients={data.clients}
          cars={data.cars}
          partsCatalog={data.parts}
          servicesCatalog={data.servicesCatalog}
          company={data.company}
          onClose={() => setActiveModal(null)}
          onSave={handleSaveOrder}
          onStockDeduct={(partId, quantity) => {
            setData(prev => ({
              ...prev,
              parts: prev.parts.map(p => p.id === partId ? { ...p, stock: Math.max(0, p.stock - quantity) } : p)
            }));
          }}
        />
      )}

      {/* 2. Официальный Печатный Бланк Заказ-наряда (ГОСТ / АвтоДилер) */}
      {activeModal === 'printOrder' && selectedOrderId && (
        <OrderPrintModal
          order={data.orders.find(o => o.id === selectedOrderId)}
          client={data.clients.find(c => c.id === (data.orders.find(o => o.id === selectedOrderId)?.clientId))}
          car={data.cars.find(cr => cr.id === (data.orders.find(o => o.id === selectedOrderId)?.carId))}
          company={data.company}
          calculateOrderTotals={calculateOrderTotals}
          onClose={() => setActiveModal(null)}
        />
      )}

      {/* 3. Модалка добавления нового клиента и автомобиля */}
      {activeModal === 'clientNew' && (
        <NewClientModal
          onClose={() => setActiveModal(null)}
          onSave={(clientData, carData) => {
            const clientId = `c-${Date.now()}`;
            const carId = `car-${Date.now()}`;
            const newClient = { id: clientId, ...clientData };
            const newCar = { id: carId, clientId: clientId, ...carData };

            setData(prev => ({
              ...prev,
              clients: [newClient, ...prev.clients],
              cars: [newCar, ...prev.cars]
            }));
            setActiveModal(null);
            showToast(`Клиент ${newClient.name} и автомобиль зарегистрированы`);
          }}
        />
      )}

      {/* 4. Модалка добавления новой запчасти на склад */}
      {activeModal === 'partNew' && (
        <NewPartModal
          onClose={() => setActiveModal(null)}
          onSave={(partData) => {
            const newPart = {
              id: `p-${Date.now()}`,
              ...partData,
              stock: Number(partData.stock) || 0,
              minStock: Number(partData.minStock) || 0,
              costPrice: Number(partData.costPrice) || 0,
              sellPrice: Number(partData.sellPrice) || 0
            };
            setData(prev => ({ ...prev, parts: [newPart, ...prev.parts] }));
            setActiveModal(null);
            showToast(`Запчасть «${newPart.name}» добавлена в номенклатуру`);
          }}
        />
      )}

      {/* 5. Добавление новой услуги в справочник */}
      {activeModal === 'serviceNew' && (
        <NewServiceModal
          onClose={() => setActiveModal(null)}
          onSave={(serviceData) => {
            const newSvc = {
              id: `s-${Date.now()}`,
              ...serviceData,
              normHours: Number(serviceData.normHours) || 1,
              price: Number(serviceData.price) || 0
            };
            setData(prev => ({ ...prev, servicesCatalog: [...prev.servicesCatalog, newSvc] }));
            setActiveModal(null);
            showToast('Услуга добавлена в каталог');
          }}
        />
      )}

      {/* 6. Модальное окно оплаты */}
      {activeModal === 'paymentModal' && selectedOrderId && (
        <PaymentModal
          order={data.orders.find(o => o.id === selectedOrderId)}
          calculateOrderTotals={calculateOrderTotals}
          onClose={() => setActiveModal(null)}
          onConfirm={(method) => handlePayOrder(selectedOrderId, method)}
        />
      )}
      {paymentReceipt && (
        <PaymentReceiptModal
          receipt={paymentReceipt}
          onClose={() => setPaymentReceipt(null)}
        />
      )}
    </div>
  );
}

// ==========================================
// ВИД 1: ДАШБОРД (АНАЛИТИКА И ОБЗОР)
// ==========================================
function VehicleInspectionView({ cars, clients }: { cars: any[]; clients: any[] }) {
  const [carId, setCarId] = useState(cars[0]?.id || '');
  const [executor, setExecutor] = useState('');
  const [mileage, setMileage] = useState('');
  const [fuel, setFuel] = useState('');
  const [keys, setKeys] = useState('2');
  const [notes, setNotes] = useState('');
  const [damages, setDamages] = useState<string[]>([]);
  const [checks, setChecks] = useState<Record<string, string>>({});
  const car = cars.find(c => c.id === carId);
  const client = clients.find(c => c.id === car?.clientId);
  const zones = ['Передний бампер','Капот','Лобовое стекло','Крыша','Заднее стекло','Крышка багажника','Задний бампер','Левая передняя дверь','Левая задняя дверь','Правая передняя дверь','Правая задняя дверь','Левое крыло','Правое крыло'];
  const toggleDamage = (z: string) => setDamages(prev => prev.includes(z) ? prev.filter(x => x !== z) : [...prev, z]);
  const statusItems = ['Кузов и ЛКП','Стёкла и зеркала','Фары и фонари','Шины и диски','Салон','Комплектность','Следы ДТП'];
  const openInspectionPreview = () => {
    const popup = window.open('', 'vehicle-inspection-preview', 'width=1000,height=800,resizable=yes,scrollbars=yes');
    if (!popup) { alert('Браузер заблокировал отдельное окно. Разрешите всплывающие окна и нажмите «Предпросмотр акта» ещё раз.'); return; }
    const esc = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch] as string));
    const rows = statusItems.map(item => `<tr><th>${esc(item)}</th><td>${esc(checks[item] || 'Не проверено')}</td></tr>`).join('');
    const html = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Предпросмотр акта осмотра</title><style>body{font:14px Arial,sans-serif;color:#111;margin:0;background:#e8ebef}.toolbar{position:sticky;top:0;background:#202936;padding:12px;text-align:right}.toolbar button{padding:10px 18px;margin-left:8px;border:0;border-radius:5px;cursor:pointer;font-weight:bold}.print{background:#f5b323}.close{background:#fff}.paper{background:white;max-width:850px;margin:22px auto;padding:34px;box-shadow:0 2px 12px #0002}h1{text-align:center;font-size:22px}h2{font-size:16px;border-bottom:1px solid #999;padding-bottom:6px;margin-top:24px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #aaa;padding:8px;text-align:left}th{width:42%;background:#f5f5f5}.damage{padding:10px;border:1px solid #aaa;min-height:35px}.signs{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:50px}.line{border-bottom:1px solid #333;height:30px}.muted{color:#555}@media print{body{background:white}.toolbar{display:none}.paper{box-shadow:none;margin:0 auto;padding:0;max-width:none}@page{size:A4;margin:15mm}}</style></head><body><div class="toolbar"><button class="close" onclick="window.close()">Закрыть</button><button class="print" onclick="window.print()">Печать акта</button></div><article class="paper"><h1>АКТ ОСМОТРА АВТОМОБИЛЯ<br><small>при приёмке в ремонт</small></h1><p><b>Дата:</b> ${esc(new Date().toLocaleDateString('ru-RU'))}</p><h2>1. Автомобиль и приёмщик</h2><table><tr><th>Автомобиль</th><td>${esc(car ? `${car.brand || ''} ${car.model || ''}`.trim() : 'Не выбран')}</td></tr><tr><th>Государственный номер</th><td>${esc(car?.plateNumber || '—')}</td></tr><tr><th>VIN</th><td>${esc(car?.vin || '—')}</td></tr><tr><th>Клиент</th><td>${esc(client?.name || '—')}</td></tr><tr><th>Пробег, км</th><td>${esc(mileage || '—')}</td></tr><tr><th>Уровень топлива</th><td>${esc(fuel || 'Не указан')}</td></tr><tr><th>Количество ключей</th><td>${esc(keys || '—')}</td></tr><tr><th>Исполнитель / приёмщик</th><td>${esc(executor || '—')}</td></tr></table><h2>2. Отмеченные повреждения</h2><div class="damage">${damages.length ? damages.map(esc).join(', ') : 'Повреждения не отмечены'}</div><h2>3. Состояние при приёмке</h2><table>${rows}</table><h2>4. Замечания и описание повреждений</h2><div class="damage">${esc(notes || 'Замечания не указаны').replace(/\n/g,'<br>')}</div><p class="muted">Автомобиль осмотрен в присутствии клиента. Состояние и отмеченные повреждения зафиксированы на момент приёмки.</p><div class="signs"><div>Исполнитель / приёмщик<div class="line"></div><small>Подпись, дата</small></div><div>Клиент<div class="line"></div><small>Подпись, дата</small></div></div></article></body></html>`;
    popup.document.open(); popup.document.write(html); popup.document.close(); popup.focus();
  };
  return <div className="flex-1 overflow-y-auto p-6 space-y-5">
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-xl font-bold text-white">Акт осмотра при приёмке автомобиля</h2><p className="text-sm text-slate-400 mt-1">Отметьте повреждения на схеме и зафиксируйте состояние автомобиля до начала работ.</p></div><button onClick={openInspectionPreview} className="bg-amber-500 text-slate-950 font-bold rounded-lg px-4 py-2 flex items-center gap-2"><Printer size={16}/> Предпросмотр / печать акта</button></div>
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
      <section className="bg-slate-800 border border-slate-700 rounded-xl p-5 space-y-4"><h3 className="font-bold text-white">Автомобиль и приёмщик</h3>
        <label className="block text-sm text-slate-300">Автомобиль из базы<select value={carId} onChange={e=>setCarId(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded-lg p-2.5 text-white">{cars.map(c=><option key={c.id} value={c.id}>{c.brand} {c.model} — {c.plateNumber}</option>)}</select></label>
        <div className="grid grid-cols-2 gap-3"><label className="text-sm text-slate-300">Госномер<input readOnly value={car?.plateNumber||''} className="mt-1 w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"/></label><label className="text-sm text-slate-300">VIN<input readOnly value={car?.vin||''} className="mt-1 w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"/></label><label className="text-sm text-slate-300">Клиент<input readOnly value={client?.name||''} className="mt-1 w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"/></label><label className="text-sm text-slate-300">Пробег, км<input value={mileage} onChange={e=>setMileage(e.target.value)} type="number" className="mt-1 w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"/></label></div>
        <div className="grid grid-cols-2 gap-3"><label className="text-sm text-slate-300">Уровень топлива<select value={fuel} onChange={e=>setFuel(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"><option value="">Не указан</option>{['Резерв','1/4','1/2','3/4','Полный'].map(x=><option key={x}>{x}</option>)}</select></label><label className="text-sm text-slate-300">Ключи, шт.<input value={keys} onChange={e=>setKeys(e.target.value)} type="number" className="mt-1 w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"/></label></div>
        <label className="block text-sm text-slate-300">Исполнитель / приёмщик<input value={executor} onChange={e=>setExecutor(e.target.value)} placeholder="ФИО сотрудника" className="mt-1 w-full bg-slate-900 border border-slate-600 rounded-lg p-2.5 text-white"/></label>
      </section>
      <section className="bg-slate-800 border border-slate-700 rounded-xl p-5"><h3 className="font-bold text-white mb-1">Схема автомобиля — отметьте повреждённые зоны</h3><p className="text-xs text-slate-400 mb-4">Схематический вид сверху, не в масштабе. Нажмите на зону, чтобы отметить её.</p><div className="grid grid-cols-2 sm:grid-cols-3 gap-2">{zones.map(z=><button key={z} onClick={()=>toggleDamage(z)} className={`rounded-lg border p-3 text-sm text-left transition ${damages.includes(z)?'bg-red-900/70 border-red-400 text-red-100':'bg-slate-900 border-slate-600 text-slate-200 hover:border-amber-400'}`}><span className="mr-2">{damages.includes(z)?'☒':'☐'}</span>{z}</button>)}</div><div className="mt-4 rounded-lg bg-slate-900 p-3 text-sm text-slate-300">Отмечено зон: <b className="text-red-300">{damages.length}</b>{damages.length>0&&<p className="mt-1">{damages.join(', ')}</p>}</div></section>
    </div>
    <section className="bg-slate-800 border border-slate-700 rounded-xl p-5"><h3 className="font-bold text-white mb-3">Состояние при приёмке</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-3">{statusItems.map(item=><div key={item} className="bg-slate-900 rounded-lg p-3 flex items-center justify-between gap-3"><span className="text-sm text-slate-200">{item}</span><select value={checks[item]||'Не проверено'} onChange={e=>setChecks(prev=>({...prev,[item]:e.target.value}))} className="bg-slate-800 border border-slate-600 rounded p-2 text-sm text-white"><option>Не проверено</option><option>Без замечаний</option><option>Есть замечания</option><option>Не применимо</option></select></div>)}</div><label className="block text-sm text-slate-300 mt-4">Описание повреждений, комплектации и замечаний<textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={4} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white" placeholder="Царапины, вмятины, вещи в салоне, предупреждения на панели..."/></label></section>
    <section className="bg-slate-800 border border-slate-700 rounded-xl p-5"><h3 className="font-bold text-white mb-3">Подтверждение</h3><p className="text-sm text-slate-300 mb-5">Автомобиль осмотрен в присутствии клиента. Отмеченные повреждения существовали на момент приёмки. Акт рекомендуется распечатать и подписать обеими сторонами.</p><div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm text-slate-300"><div>Исполнитель: {executor||'________________________'}<div className="border-b border-slate-500 mt-8"/>Подпись / дата</div><div>Клиент: {client?.name||'________________________'}<div className="border-b border-slate-500 mt-8"/>Подпись / дата</div></div></section>
    <style>{`@media print { body * { visibility: hidden !important; } main, main * { visibility: visible !important; } main { overflow: visible !important; position: absolute; inset: 0; background: white !important; color: black !important; } main section, main div { break-inside: avoid; } main .bg-slate-800, main .bg-slate-900 { background: white !important; color: black !important; border-color: #999 !important; } main input, main textarea, main select { color: black !important; border-color: #999 !important; } aside, header { display: none !important; } }`}</style>
  </div>;
}


function ServiceContractView({ company, cars, clients }: { company: any; cars: any[]; clients: any[] }) {
  const [carId, setCarId] = useState(cars[0]?.id || '');
  const [clientId, setClientId] = useState(cars[0]?.clientId || clients[0]?.id || '');
  const [contractNo, setContractNo] = useState(`Д-${new Date().getFullYear()}-001`);
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0,10));
  const [endDate, setEndDate] = useState('');
  const [work, setWork] = useState('Диагностика и ремонт согласно согласованному заказ-наряду');
  const [price, setPrice] = useState('');
  const [payment, setPayment] = useState('Оплата после выполнения работ по согласованному заказ-наряду');
  const [parts, setParts] = useState('Запасные части и материалы согласовываются с заказчиком отдельно');
  const [warranty, setWarranty] = useState('Гарантия указывается в заказ-наряде, если установлена исполнителем');
  const [terms, setTerms] = useState(true);
  const [extra, setExtra] = useState(false);
  const car = cars.find(c => c.id === carId);
  const client = clients.find(c => c.id === clientId) || clients.find(c => c.id === car?.clientId);
  const esc = (v: unknown) => String(v ?? '—').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch] as string));
  const preview = () => {
    if (!terms) { alert('Подтвердите, что условия договора согласованы с заказчиком.'); return; }
    const w = window.open('', 'service-contract-preview', 'width=1000,height=800,resizable=yes,scrollbars=yes');
    if (!w) { alert('Разрешите всплывающие окна для предпросмотра договора.'); return; }
    const html = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Договор оказания услуг</title><style>body{font:14px Arial;color:#111;background:#e8ebef;margin:0}.bar{position:sticky;top:0;background:#202936;padding:12px;text-align:right}.bar button{padding:10px 16px;margin-left:8px;cursor:pointer}.paper{max-width:850px;background:white;margin:20px auto;padding:36px;line-height:1.45}h1{text-align:center;font-size:20px}h2{font-size:15px;margin-top:22px}p{margin:8px 0}.sign{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:50px}.line{border-bottom:1px solid #222;height:32px}.muted{font-size:11px;color:#555}@media print{body{background:white}.bar{display:none}.paper{margin:0 auto;padding:0;max-width:none}@page{size:A4;margin:15mm}}</style></head><body><div class="bar"><button onclick="window.close()">Закрыть</button><button onclick="window.print()">Печать договора</button></div><article class="paper"><h1>ДОГОВОР № ${esc(contractNo)}<br>возмездного оказания услуг и выполнения работ по техническому обслуживанию и ремонту автомобиля</h1><p>г. ____________________ &nbsp;&nbsp; Дата: ${esc(date)}</p><p><b>Исполнитель:</b> ${esc(company?.name)}, адрес: ${esc(company?.address)}, ИНН: ${esc(company?.inn)}, телефон: ${esc(company?.phone)}, в лице уполномоченного представителя, с одной стороны, и <b>Заказчик:</b> ${esc(client?.name)}, телефон: ${esc(client?.phone || 'не указан')}, с другой стороны, заключили настоящий договор о нижеследующем.</p><h2>1. Предмет договора</h2><p>1.1. Исполнитель обязуется выполнить согласованные работы/оказать услуги: <b>${esc(work)}</b>, а Заказчик обязуется принять и оплатить их на условиях настоящего договора и согласованного заказ-наряда.</p><p>1.2. Автомобиль: ${esc(car ? `${car.brand || ''} ${car.model || ''}`.trim() : 'не выбран')}; госномер: ${esc(car?.plateNumber)}; VIN: ${esc(car?.vin)}.</p><h2>2. Сроки выполнения</h2><p>2.1. Дата приёма заказа: ${esc(date)}. Начало работ: ${esc(startDate)}. Планируемое окончание: ${esc(endDate || 'согласуется сторонами / указывается в заказ-наряде')}.</p><h2>3. Цена и порядок оплаты</h2><p>3.1. Стоимость работ и услуг: ${esc(price ? `${price} руб.` : 'указывается в согласованном заказ-наряде/смете до начала работ')}.</p><p>3.2. Порядок оплаты: ${esc(payment)}.</p><h2>4. Запасные части и материалы</h2><p>4.1. Условия использования и согласования запчастей/материалов: ${esc(parts)}. Дополнительные работы и изменение стоимости согласуются с Заказчиком до их выполнения.</p><h2>5. Права и обязанности сторон</h2><p>5.1. Исполнитель выполняет работы в согласованном объёме и информирует Заказчика о выявленных дополнительных неисправностях, требующих согласования.</p><p>5.2. Заказчик предоставляет достоверные сведения об автомобиле и заявленных неисправностях, принимает результат и оплачивает согласованные работы.</p><p>5.3. При передаче автомобиля оформляется акт приёма-передачи/осмотра с указанием комплектности и видимых повреждений. Заказчику выдаётся его экземпляр договора и акта.</p><h2>6. Приёмка результата и гарантия</h2><p>6.1. Результат работ принимается сторонами после завершения работ. Замечания фиксируются письменно.</p><p>6.2. Гарантийные условия: ${esc(warranty)}. Условия гарантии не ограничивают права потребителя, предоставленные законом.</p><h2>7. Заключительные положения</h2><p>7.1. Споры разрешаются в соответствии с законодательством Российской Федерации.</p><p>7.2. Договор составляется в двух экземплярах, по одному для каждой стороны, если иной порядок не согласован сторонами.</p><h2>8. Реквизиты и подписи сторон</h2><p><b>Исполнитель:</b> ${esc(company?.name)}<br>Адрес: ${esc(company?.address)}<br>ИНН: ${esc(company?.inn)}<br>Телефон: ${esc(company?.phone)}</p><p><b>Заказчик:</b> ${esc(client?.name)}<br>Телефон: ${esc(client?.phone || '________________')}</p><div class="sign"><div>Исполнитель<div class="line"></div><small>Подпись / ФИО</small></div><div>Заказчик<div class="line"></div><small>Подпись / ФИО</small></div></div><p class="muted">Шаблон для заполнения. До применения проверьте реквизиты, индивидуальные условия и актуальность законодательства. Договор не заменяет заказ-наряд и акт приёма-передачи, когда они необходимы.</p></article></body></html>`;
    w.document.open(); w.document.write(html); w.document.close(); w.focus();
  };
  return <div className="flex-1 overflow-y-auto p-6 space-y-5"><div className="bg-slate-800 border border-slate-700 rounded-xl p-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-xl font-bold text-white">Договор оказания услуг</h2><p className="text-sm text-slate-400 mt-1">Заполните условия и откройте отдельный предпросмотр перед печатью.</p></div><button onClick={preview} className="bg-amber-500 text-slate-950 font-bold rounded-lg px-4 py-2 flex items-center gap-2"><Printer size={16}/> Предпросмотр / печать договора</button></div>
  <div className="rounded-xl border border-amber-700/50 bg-amber-950/30 p-4 text-sm text-amber-100">Перед началом работ договор должен быть оформлен письменно. Для ремонта автомобиля обычно одновременно оформляют заказ-наряд и акт приёма-передачи с комплектностью и видимыми повреждениями. Проверьте применимость актуальных Правил РФ и заполните реквизиты организации.</div>
  <section className="bg-slate-800 border border-slate-700 rounded-xl p-5 grid grid-cols-1 md:grid-cols-2 gap-4"><label className="text-sm text-slate-300">Номер договора<input value={contractNo} onChange={e=>setContractNo(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300">Дата договора<input type="date" value={date} onChange={e=>setDate(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300">Заказчик<select value={clientId} onChange={e=>setClientId(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white">{clients.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label className="text-sm text-slate-300">Автомобиль<select value={carId} onChange={e=>{setCarId(e.target.value); const found=cars.find(c=>c.id===e.target.value); if(found?.clientId)setClientId(found.clientId)}} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white">{cars.map(c=><option key={c.id} value={c.id}>{c.brand} {c.model} — {c.plateNumber}</option>)}</select></label><label className="text-sm text-slate-300">Начало работ<input type="date" value={startDate} onChange={e=>setStartDate(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300">Планируемое окончание<input type="date" value={endDate} onChange={e=>setEndDate(e.target.value)} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300 md:col-span-2">Работы / услуги<textarea value={work} onChange={e=>setWork(e.target.value)} rows={2} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300">Цена, руб.<input value={price} onChange={e=>setPrice(e.target.value)} placeholder="Сумма или оставить пустым" className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300">Порядок оплаты<textarea value={payment} onChange={e=>setPayment(e.target.value)} rows={2} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300 md:col-span-2">Запчасти и материалы<textarea value={parts} onChange={e=>setParts(e.target.value)} rows={2} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="text-sm text-slate-300 md:col-span-2">Гарантийные условия<textarea value={warranty} onChange={e=>setWarranty(e.target.value)} rows={2} className="mt-1 w-full bg-slate-900 border border-slate-600 rounded p-2.5 text-white"/></label><label className="md:col-span-2 flex gap-3 items-start text-sm text-slate-300"><input type="checkbox" checked={terms} onChange={e=>setTerms(e.target.checked)} className="mt-1"/>Подтверждаю, что цена, объём работ, сроки и условия будут согласованы с заказчиком до подписания договора.</label></section>
  <p className="text-xs text-slate-400">Шаблон не является юридическим заключением. Обязательно внесите реальные реквизиты исполнителя и проверьте форму у юриста с учётом действующих правил РФ.</p></div>;
}

function CarCatalogView() {
  const [query, setQuery] = useState('');
  const [make, setMake] = useState('Все производители');
  const [selected, setSelected] = useState<[string, string] | null>(null);
  const [section, setSection] = useState<'catalog'|'maintenance'|'systems'|'diagnostics'|'diagrams'>('catalog');
  const [guide, setGuide] = useState<string | null>(null);
  const cars: [string,string][] = [
    ['Acura','Integra'],['Audi','A3'],['Audi','A4'],['Audi','A6'],['BMW','1 Series'],['BMW','3 Series'],['BMW','5 Series'],['BMW','X1'],['BMW','X3'],['BMW','X5'],['BYD','Atto 3'],['Chevrolet','Aveo'],['Chevrolet','Cruze'],['Chevrolet','Malibu'],['Chery','Tiggo 4'],['Chery','Tiggo 7'],['Chery','Tiggo 8'],['Citroën','C3'],['Daewoo','Matiz'],['Dodge','Charger'],['Fiat','500'],['Ford','Focus'],['Ford','Mondeo'],['Ford','Mustang'],['Geely','Atlas'],['Geely','Coolray'],['Genesis','G80'],['Great Wall','Hover H5'],['Honda','Accord'],['Honda','Civic'],['Honda','CR-V'],['Hyundai','Accent'],['Hyundai','Solaris'],['Hyundai','Tucson'],['Hyundai','Santa Fe'],['Infiniti','QX50'],['Isuzu','D-Max'],['Jaguar','XE'],['Jeep','Grand Cherokee'],['Kia','Ceed'],['Kia','Rio'],['Kia','Sportage'],['Kia','Sorento'],['Lada','Granta'],['Lada','Vesta'],['Lada','Largus'],['Land Rover','Defender'],['Land Rover','Discovery'],['Lexus','ES'],['Lexus','RX'],['Mazda','3'],['Mazda','6'],['Mazda','CX-5'],['Mercedes-Benz','A-Class'],['Mercedes-Benz','C-Class'],['Mercedes-Benz','E-Class'],['Mercedes-Benz','GLC'],['Mitsubishi','Lancer'],['Mitsubishi','Outlander'],['Nissan','Almera'],['Nissan','Qashqai'],['Nissan','X-Trail'],['Opel','Astra'],['Opel','Insignia'],['Peugeot','308'],['Peugeot','408'],['Porsche','Cayenne'],['Renault','Logan'],['Renault','Duster'],['Renault','Megane'],['Skoda','Fabia'],['Skoda','Octavia'],['Skoda','Rapid'],['Skoda','Superb'],['Skoda','Kodiaq'],['Subaru','Forester'],['Suzuki','Vitara'],['Tesla','Model 3'],['Tesla','Model Y'],['Toyota','Camry'],['Toyota','Corolla'],['Toyota','RAV4'],['Toyota','Land Cruiser'],['Volkswagen','Golf'],['Volkswagen','Passat'],['Volkswagen','Polo'],['Volkswagen','Tiguan'],['Volvo','S60'],['Volvo','XC60'],['Москвич','3'],['УАЗ','Патриот']
  ];
  const makes = ['Все производители', ...Array.from(new Set(cars.map(c => c[0]))).sort((a,b)=>a.localeCompare(b,'ru'))];
  const filtered = cars.filter(c => (make === 'Все производители' || c[0] === make) && c.join(' ').toLowerCase().includes(query.toLowerCase()));
  const maintenance = [
    {id:'oil',title:'Замена моторного масла и фильтра',level:'Базовое обслуживание',steps:['Уточните по VIN/руководству точный допуск масла, объём и тип фильтра.','Поставьте автомобиль на ровную площадку, зафиксируйте колёса; дайте двигателю остыть до безопасной температуры.','Подготовьте ёмкость для отработки и подходящий инструмент. Поднимайте автомобиль только на штатных точках и установите опоры — не работайте под машиной, удерживаемой одним домкратом.','Слейте масло по процедуре изготовителя, замените фильтр и уплотнение пробки, соблюдая указанный момент затяжки.','Залейте масло нужного допуска и объёма, проверьте уровень способом из руководства. Запустите двигатель, проверьте отсутствие утечек и повторно проверьте уровень.','Сбросьте сервисный интервал по инструкции конкретной модели и сдайте отработку в пункт приёма.']},
    {id:'brakes',title:'Проверка тормозной системы',level:'Безопасность — критично',steps:['Проверьте уровень тормозной жидкости и наличие предупреждений на панели.','Осмотрите шины, видимые участки шлангов и трубок на повреждения/утечки.','Измерьте толщину колодок и дисков и сравните с пределами изготовителя именно для этой модификации.','Проверьте равномерность износа, состояние пыльников и отсутствие подклинивания.','После ремонта тормозов выполняйте прокачку и проверку только по процедуре производителя; перед выездом проверьте педаль и торможение на безопасной площадке.','При утечке, мягкой педали, трещинах или сомнении не эксплуатируйте автомобиль — доставьте его в сервис.']},
    {id:'coolant',title:'Проверка охлаждающей системы',level:'Базовая диагностика',steps:['На полностью остывшем двигателе проверьте уровень в расширительном бачке. Не открывайте горячую систему под давлением.','Осмотрите радиатор, патрубки, соединения и помпу на следы подтекания.','Проверьте состояние ремня привода, если он предусмотрен конструкцией и доступен для осмотра.','Если двигатель перегревается, остановитесь в безопасном месте и заглушите его; не продолжайте движение при предупреждении о перегреве.','Подбор антифриза, процедура заполнения и удаления воздуха — строго по руководству конкретного автомобиля.']},
    {id:'battery',title:'Аккумулятор и система зарядки',level:'Базовая диагностика',steps:['Осмотрите корпус батареи и крепление; не работайте с вздутой или повреждённой батареей.','Проверьте клеммы на окисление и надёжность крепления при выключенном зажигании.','Измерьте напряжение мультиметром по инструкции прибора; оценивать заряд и генератор нужно с учётом типа батареи и системы управления.','Если требуется отключение, соблюдайте порядок изготовителя: могут потребоваться код магнитолы, регистрация батареи или сохранение настроек.','При запахе серы, нагреве, дыме или искрении прекратите работу и обратитесь к специалисту.']},
    {id:'tires',title:'Шины, давление и износ',level:'Регулярный осмотр',steps:['Проверяйте давление на холодных шинах по табличке автомобиля, а не по максимальному значению на боковине.','Осмотрите протектор, боковины, порезы, грыжи и неравномерный износ.','Сравните глубину протектора с требованиями закона и изготовителя для сезона и типа шин.','Перестановку колёс выполняйте только по схеме для конкретных шин (направленные/разноширокие могут ограничивать перестановку).','После снятия колёс затягивайте крепёж динамометрическим ключом моментом, указанным производителем.']},
    {id:'filters',title:'Воздушный и салонный фильтры',level:'Плановое обслуживание',steps:['Уточните каталожный номер фильтра по VIN, двигателю и году выпуска.','Найдите корпус фильтра по руководству; не тяните за проводку и датчики.','Перед открытием корпуса очистите окружающую поверхность от пыли.','Установите фильтр в правильной ориентации, проверьте посадку уплотнения и защёлок.','Для салонного фильтра соблюдайте стрелку направления воздушного потока; после сборки проверьте работу вентилятора.']}
  ];
  const systems = [
    {title:'Двигатель и смазка',desc:'Блок цилиндров, головка блока, газораспределительный механизм, смазка и впуск/выпуск.',items:['Двигатель не запускается','Шум или вибрация двигателя','Повышенный расход масла','Потеря мощности']},
    {title:'Охлаждение и отопление',desc:'Радиатор, термостат, насос охлаждающей жидкости, вентилятор, отопитель и кондиционер.',items:['Перегрев двигателя','Печка дует холодным воздухом','Утечка охлаждающей жидкости','Кондиционер не охлаждает']},
    {title:'Топливо и зажигание',desc:'Топливный бак/насос, форсунки, свечи, катушки и система управления двигателем.',items:['Двигатель троит','Трудный запуск','Повышенный расход топлива','Ошибки двигателя']},
    {title:'Трансмиссия и привод',desc:'Сцепление, механическая/автоматическая коробка, дифференциал, приводы и ШРУСы.',items:['Пробуксовка сцепления','Рывки коробки передач','Шум при повороте','Утечка масла трансмиссии']},
    {title:'Тормоза и ABS',desc:'Диски, колодки, суппорты, гидропривод, стояночный тормоз и электронная система ABS.',items:['Скрип или вибрация при торможении','Увод автомобиля в сторону','Горит ABS','Мягкая педаль тормоза']},
    {title:'Подвеска и рулевое управление',desc:'Амортизаторы, пружины, рычаги, шаровые опоры, рулевые тяги и усилитель руля.',items:['Стук на неровностях','Люфт руля','Неравномерный износ шин','Автомобиль уводит в сторону']},
    {title:'Электрика и запуск',desc:'Аккумулятор, стартер, генератор, предохранители, реле, датчики и проводка.',items:['Не крутит стартер','Не заряжается аккумулятор','Не работают фары','Перегорает предохранитель']},
    {title:'Кузов, безопасность и ADAS',desc:'Ремни, подушки безопасности, датчики парковки, камеры и системы помощи водителю.',items:['Горит индикатор подушки безопасности','Не работает камера','Повреждение кузова после ДТП','Ошибка системы помощи водителю']}
  ];
  const diagramLinks = [
    {title:'Руководства и схемы Volkswagen',desc:'Официальная документация, ремонтные руководства, электрические схемы и регламент обслуживания.',url:'https://volkswagen.erwin-store.com/erwin/showInfoTour.do'},
    {title:'Примеры ремонтных документов Audi',desc:'Примеры заводских ремонтных руководств и электрических схем.',url:'https://audi-eu-qs2.erwin-store.com/erwin/showExampleDocuments.do'},
    {title:'Сервисная документация Škoda',desc:'Ремонтные руководства, схемы, таблицы обслуживания и техническая информация.',url:'https://skoda.erwin-store.com/erwin/showInfoTour.do'},
    {title:'Car Care Guide — обслуживание',desc:'Общее руководство по уходу за автомобилем, системам и периодическому обслуживанию (английский).',url:'https://www.carcare.org/car-care-resources/car-care-guide/'},
    {title:'AAA — статьи по диагностике и ремонту',desc:'Материалы по тормозам, маслу, аккумулятору, предупреждениям и профилактике.',url:'https://mwg.aaa.com/automotive/auto-repair/articles'},
    {title:'Haynes — ремонтные руководства',desc:'Поиск руководств по конкретной марке и модели; часть материалов платная.',url:'https://uk.haynes.com/'}
  ];
  const nav = [ ['catalog','Каталог марок'],['maintenance','ТО и ремонт'],['systems','Устройство авто'],['diagnostics','Поиск неисправностей'],['diagrams','Схемы и руководства'] ] as const;
  const linkSearch = (term:string) => `https://www.google.com/search?q=${encodeURIComponent(term+' схема устройство ремонт руководство')}`;
  return <section className="bg-slate-800/70 border border-slate-700 rounded-xl p-5 space-y-4">
    <div><h2 className="text-lg font-bold text-slate-100">Справочник автомобилей: устройство, обслуживание и ремонт</h2><p className="text-sm text-slate-400 mt-1">Выберите марку/модель или откройте практические инструкции. Заводские схемы и моменты затяжки зависят от года, двигателя и комплектации.</p></div>
    <div className="flex flex-wrap gap-2">{nav.map(([id,label])=><button key={id} type="button" onClick={()=>{setSection(id);setGuide(null);}} className={`rounded-lg border px-3 py-2 text-sm font-semibold ${section===id?'bg-amber-500 border-amber-400 text-slate-950':'bg-slate-900 border-slate-600 text-slate-200 hover:border-amber-400'}`}>{label}</button>)}</div>
    {section==='catalog'&&<><div className="flex flex-wrap gap-3"><div className="relative flex-1 min-w-56"><Search className="w-4 h-4 absolute left-3 top-3 text-slate-400"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Поиск марки или модели..." className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white outline-none focus:border-amber-500"/></div><select value={make} onChange={e=>setMake(e.target.value)} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white">{makes.map(m=><option key={m} value={m}>{m}</option>)}</select><button type="button" onClick={()=>{setMake('Все производители');setQuery('');setSelected(null);}} className="border border-slate-600 hover:border-amber-500 text-slate-200 rounded-lg px-4 py-2 text-sm">Сбросить фильтр</button></div><p className="text-xs text-slate-400">Найдено моделей: {filtered.length}. Нажмите на карточку модели, чтобы открыть сведения и ссылки на материалы.</p><div className="flex flex-wrap gap-2">{makes.filter(m=>m!=='Все производители'&&(!query||m.toLowerCase().includes(query.toLowerCase()))).map(m=><button key={m} type="button" onClick={()=>{setMake(m);setQuery('');setSelected(null);}} className={`rounded-full border px-3 py-1.5 text-sm font-semibold ${make===m?'bg-amber-500 border-amber-400 text-slate-950':'bg-slate-900 border-slate-600 text-slate-200 hover:border-amber-400 hover:text-amber-300'}`}>{m}</button>)}</div><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">{filtered.map(([brand,model])=><button type="button" key={brand+'-'+model} onClick={()=>setSelected([brand,model])} className="text-left flex items-center gap-3 bg-slate-900/70 border border-slate-700 rounded-lg p-3 hover:border-amber-400 hover:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"><Car className="w-5 h-5 text-amber-500 shrink-0"/><span><b className="block text-sm text-slate-100">{brand}</b><span className="block text-xs text-slate-300">{model}</span><span className="block text-[11px] text-amber-400 mt-1">Открыть ремонтные материалы →</span></span></button>)}</div>{filtered.length===0&&<p className="text-sm text-slate-400 py-6 text-center">Ничего не найдено</p>}{selected&&<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onMouseDown={e=>{if(e.target===e.currentTarget)setSelected(null);}}><div role="dialog" aria-modal="true" className="w-full max-w-lg max-h-[90vh] overflow-auto rounded-xl border border-slate-600 bg-slate-800 p-5 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-xs uppercase tracking-wide text-amber-400">Автомобиль выбран</p><h3 className="mt-1 text-xl font-bold text-white">{selected[0]} {selected[1]}</h3></div><button type="button" onClick={()=>setSelected(null)} aria-label="Закрыть" className="rounded-lg p-2 text-slate-300 hover:bg-slate-700"><X className="w-5 h-5"/></button></div><p className="text-sm text-slate-300 mt-3">Для точной инструкции уточните год выпуска, двигатель и модификацию. Пока можно открыть поиск схем и руководств для выбранной модели.</p><div className="mt-4 grid gap-2">{['руководство по ремонту','электрическая схема','регламент технического обслуживания','схема предохранителей','диагностика неисправностей'].map(t=><a key={t} href={linkSearch(`${selected[0]} ${selected[1]} ${t}`)} target="_blank" rel="noreferrer" className="rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm text-amber-300 hover:border-amber-400">{t} ↗</a>)}</div><div className="mt-5 flex justify-end"><button type="button" onClick={()=>setSelected(null)} className="rounded-lg bg-amber-500 px-4 py-2 font-semibold text-slate-950">Закрыть</button></div></div></div>}</>}
    {section==='maintenance'&&<><h3 className="text-base font-bold text-white">Пошаговые инструкции по обслуживанию</h3><p className="text-sm text-slate-400">Это базовые общие инструкции, не заменяющие руководство конкретного автомобиля.</p><div className="grid gap-3">{maintenance.map(g=><article key={g.id} className="rounded-lg border border-slate-700 bg-slate-900/70 p-4"><button type="button" onClick={()=>setGuide(guide===g.id?null:g.id)} className="w-full text-left flex items-center justify-between gap-3"><span><b className="text-slate-100">{g.title}</b><span className="block text-xs text-amber-400 mt-1">{g.level}</span></span><span className="text-amber-400">{guide===g.id?'−':'+'}</span></button>{guide===g.id&&<ol className="mt-3 list-decimal pl-5 space-y-2 text-sm text-slate-300">{g.steps.map((step,i)=><li key={i}>{step}</li>)}</ol>}</article>)}</div></>}
    {section==='systems'&&<><h3 className="text-base font-bold text-white">Устройство автомобиля по системам</h3><div className="grid md:grid-cols-2 gap-3">{systems.map((sys,i)=><article key={sys.title} className="rounded-lg border border-slate-700 bg-slate-900/70 p-4"><h4 className="font-semibold text-amber-300">{i+1}. {sys.title}</h4><p className="text-sm text-slate-300 mt-2">{sys.desc}</p><p className="text-xs text-slate-400 mt-3">Частые темы:</p><div className="flex flex-wrap gap-2 mt-2">{sys.items.map(item=><a key={item} target="_blank" rel="noreferrer" href={linkSearch(item)} className="text-xs rounded-full border border-slate-600 px-2 py-1 text-slate-200 hover:border-amber-400">{item} ↗</a>)}</div><a target="_blank" rel="noreferrer" href={linkSearch(sys.title)} className="inline-block mt-3 text-sm text-amber-300 hover:underline">Найти схему системы ↗</a></article>)}</div></>}
    {section==='diagnostics'&&<><h3 className="text-base font-bold text-white">Поиск неисправностей по симптомам</h3><p className="text-sm text-slate-400">Выберите симптом, чтобы открыть материалы по возможным причинам и проверкам. Диагностируйте от простого к сложному, не заменяйте детали без проверки.</p><div className="grid sm:grid-cols-2 gap-2">{['Двигатель не запускается','Двигатель перегревается','Горит Check Engine','Горит индикатор аккумулятора','Стук в подвеске','Скрипят тормоза','Автомобиль вибрирует','Коробка передач дёргается','Плохо греет печка','Повышенный расход топлива','Не работают фары','Утечка масла'].map(symptom=><a key={symptom} target="_blank" rel="noreferrer" href={linkSearch(symptom)} className="rounded-lg border border-slate-700 bg-slate-900/70 p-3 text-sm text-slate-100 hover:border-amber-400"><Search className="inline w-4 h-4 mr-2 text-amber-400"/>{symptom} <span className="text-amber-400">↗</span></a>)}</div><div className="rounded-lg border border-rose-900/70 bg-rose-950/30 p-3 text-sm text-rose-200">Если неисправны тормоза, рулевое управление, шины, есть утечка топлива, дым, перегрев или предупреждение о высоковольтной системе — остановите автомобиль безопасно и обратитесь в сервис.</div></>}
    {section==='diagrams'&&<><h3 className="text-base font-bold text-white">Схемы, заводские руководства и материалы из интернета</h3><p className="text-sm text-slate-400">Ссылки открывают внешние сайты. Доступность, язык и стоимость документов зависят от производителя; для точной схемы выбирайте модель, год и двигатель.</p><div className="grid md:grid-cols-2 gap-3">{diagramLinks.map(link=><article key={link.title} className="rounded-lg border border-slate-700 bg-slate-900/70 p-4"><h4 className="font-semibold text-slate-100">{link.title}</h4><p className="text-sm text-slate-400 mt-2">{link.desc}</p><a href={link.url} target="_blank" rel="noreferrer" className="inline-block mt-3 text-sm font-semibold text-amber-300 hover:underline">Открыть ресурс ↗</a></article>)}</div><div className="rounded-lg border border-slate-700 bg-slate-900/70 p-4"><h4 className="font-semibold text-white">Быстрый поиск схемы</h4><p className="text-sm text-slate-400 mt-1">Уточните модель в запросе. Поиск откроется в браузере.</p><div className="flex flex-wrap gap-2 mt-3">{['электрическая схема','схема предохранителей','схема двигателя','схема подвески','руководство по ремонту'].map(term=><a key={term} target="_blank" rel="noreferrer" href={linkSearch(`${make==='Все производители'?'автомобиль':make} ${query} ${term}`)} className="rounded-lg border border-slate-600 px-3 py-2 text-sm text-amber-300 hover:border-amber-400">{term} ↗</a>)}</div></div></>}
    <p className="text-xs text-slate-500 border-t border-slate-700 pt-3">Справочник содержит учебные общие материалы и ссылки на внешние источники. Заводские схемы, моменты затяжки, жидкости и процедуры нужно сверять по VIN и официальной документации. Не выполняйте работы с подушками безопасности, топливом под давлением, высоковольтными гибридными/электрическими системами и критическими узлами без квалификации.</p>
  </section>;
}

function DashboardView({ stats, orders, clients, cars, parts, calculateOrderTotals, onOpenOrder, onPrintOrder, onQuickCreateOrder, onQuickAddPart }) {
  const recentOrders = useMemo(() => {
    return [...orders].slice(0, 5);
  }, [orders]);

  const criticalParts = useMemo(() => {
    return parts.filter(p => p.stock <= p.minStock);
  }, [parts]);

  return (
    <div className="space-y-6">
      {/* Карточки KPI */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>В РАБОТЕ В ЦЕХУ</span>
            <Wrench className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white">{stats.activeOrdersCount}</span>
            <span className="text-xs text-slate-400">заказ-нарядов</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-400 border-t border-slate-700/50 pt-2 flex justify-between">
            <span>Всего клиентов: {stats.totalClients}</span>
            <span>Автомобилей: {stats.totalCars}</span>
          </div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>ВЫРУЧКА СЕГОДНЯ</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-400">{stats.todayIncome.toLocaleString('ru-RU')} ₽</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-400 border-t border-slate-700/50 pt-2">
            Общая сумма оплат: <span className="text-slate-200">{stats.totalIncome.toLocaleString('ru-RU')} ₽</span>
          </div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>СРЕДНИЙ ЧЕК</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-blue-400">{stats.averageBill.toLocaleString('ru-RU')} ₽</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-400 border-t border-slate-700/50 pt-2">
            По всем оплаченным нарядам
          </div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>ДЕФИЦИТ НА СКЛАДЕ</span>
            <AlertTriangle className={`w-4 h-4 ${stats.lowStockPartsCount > 0 ? 'text-rose-500 animate-pulse' : 'text-slate-400'}`} />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl font-bold ${stats.lowStockPartsCount > 0 ? 'text-rose-400' : 'text-slate-200'}`}>
              {stats.lowStockPartsCount}
            </span>
            <span className="text-xs text-slate-400">позиций требуют дозаказа</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-400 border-t border-slate-700/50 pt-2">
            Ниже минимального остатка
          </div>
        </div>
      </div>

      {/* Панель Быстрых Действий */}
      <div className="bg-gradient-to-r from-slate-800 via-slate-800 to-slate-800/60 p-4 rounded-xl border border-slate-700 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 className="text-sm font-bold text-white">Быстрые операции приёмки</h2>
          <p className="text-xs text-slate-400">Оформление нового клиента или поступление запчастей в один клик</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onQuickCreateOrder}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-2 shadow-md cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4" />
            Оформить заказ-наряд
          </button>
          <button
            onClick={onQuickAddPart}
            className="bg-slate-700 hover:bg-slate-600 text-slate-100 font-medium px-3.5 py-2 rounded-lg text-xs flex items-center gap-2 cursor-pointer transition-all"
          >
            <Package className="w-4 h-4 text-amber-400" />
            Оприходовать деталь
          </button>
        </div>
      </div>

      {/* Таблицы: Последние заказ-наряды + Заканчивающиеся запчасти */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Последние заказы */}
        <div className="lg:col-span-2 bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
          <div className="px-5 py-3.5 border-b border-slate-700/80 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-500" />
              Последние открытые заказ-наряды
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-700/50">
                <tr>
                  <th className="py-2.5 px-4">№ Заказа</th>
                  <th className="py-2.5 px-4">Клиент / Автомобиль</th>
                  <th className="py-2.5 px-4">Статус</th>
                  <th className="py-2.5 px-4 text-right">Сумма</th>
                  <th className="py-2.5 px-4 text-center">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40 text-slate-200">
                {recentOrders.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-500">Заказ-нарядов пока нет</td>
                  </tr>
                ) : (
                  recentOrders.map(order => {
                    const client = clients.find(c => c.id === order.clientId);
                    const car = cars.find(c => c.id === order.carId);
                    const { finalTotal } = calculateOrderTotals(order);
                    const statusObj = ORDER_STATUSES.find(s => s.label === order.status) || ORDER_STATUSES[0];

                    return (
                      <tr key={order.id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="py-3 px-4 font-bold text-amber-400">
                          {order.id}
                          <div className="text-[10px] text-slate-400 font-normal">{order.date}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-100">{client?.name || 'Клиент не указан'}</div>
                          <div className="text-[11px] text-slate-400 flex items-center gap-1">
                            <Car className="w-3 h-3 text-slate-500" />
                            {car ? `${car.brand} ${car.model} (${car.plateNumber})` : '—'}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${statusObj.color}`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-slate-100">
                          {finalTotal.toLocaleString('ru-RU')} ₽
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => onOpenOrder(order.id)}
                              title="Открыть заказ-наряд"
                              className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 cursor-pointer"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => onPrintOrder(order.id)}
                              title="Печать заказ-наряда"
                              className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-amber-400 cursor-pointer"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Заканчивающиеся запчасти */}
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm flex flex-col">
          <div className="px-5 py-3.5 border-b border-slate-700/80 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" />
              Критический остаток
            </h3>
            <span className="text-xs bg-rose-950 text-rose-400 border border-rose-800 px-2 py-0.5 rounded-full font-bold">
              {criticalParts.length} поз.
            </span>
          </div>
          <div className="p-3 flex-1 overflow-y-auto space-y-2">
            {criticalParts.length === 0 ? (
              <div className="text-xs text-slate-400 text-center py-8">
                Все складские остатки в пределах нормы.
              </div>
            ) : (
              criticalParts.map(part => (
                <div key={part.id} className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-700/60 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-200">{part.name}</div>
                    <div className="text-[11px] text-slate-400">Арт: <span className="text-amber-400 font-mono">{part.article}</span></div>
                  </div>
                  <div className="text-right">
                    <div className="text-rose-400 font-bold">{part.stock} шт.</div>
                    <div className="text-[10px] text-slate-500">мин: {part.minStock} шт.</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// ВИД 2: ЖУРНАЛ ЗАКАЗ-НАРЯДОВ
// ==========================================
function OrdersView({ orders, clients, cars, filterStatus, setFilterStatus, searchQuery, setSearchQuery, calculateOrderTotals, onOpenOrder, onPrintOrder, onPayOrderPrompt, onDeleteOrder, onCreateNew }) {
  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      // Фильтр по статусу
      if (filterStatus !== 'Все' && order.status !== filterStatus) {
        return false;
      }
      // Поиск
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const client = clients.find(c => c.id === order.clientId);
        const car = cars.find(c => c.id === order.carId);
        const matchesId = order.id.toLowerCase().includes(q);
        const matchesClient = client && client.name.toLowerCase().includes(q);
        const matchesPlate = car && car.plateNumber.toLowerCase().includes(q);
        const matchesVin = car && car.vin.toLowerCase().includes(q);
        return matchesId || matchesClient || matchesPlate || matchesVin;
      }
      return true;
    });
  }, [orders, clients, cars, filterStatus, searchQuery]);

  return (
    <div className="space-y-4">
      {/* Панель фильтров и поиска */}
      <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-xl flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="flex flex-1 items-center gap-2 w-full">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Поиск по номеру наряда, клиенту, госномеру или VIN..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto py-1">
            <button
              onClick={() => setFilterStatus('Все')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer whitespace-nowrap transition-all ${
                filterStatus === 'Все'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Все ({orders.length})
            </button>
            {ORDER_STATUSES.map(st => {
              const count = orders.filter(o => o.status === st.label).length;
              return (
                <button
                  key={st.label}
                  onClick={() => setFilterStatus(st.label)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer whitespace-nowrap transition-all ${
                    filterStatus === st.label
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {st.label} ({count})
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={onCreateNew}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 shadow-md whitespace-nowrap cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" />
          Создать заказ-наряд
        </button>
      </div>

      {/* Таблица заказов */}
      <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-700/60">
              <tr>
                <th className="py-3 px-4">Номер / Дата</th>
                <th className="py-3 px-4">Клиент</th>
                <th className="py-3 px-4">Автомобиль</th>
                <th className="py-3 px-4">Мастер / Пост</th>
                <th className="py-3 px-4">Статус</th>
                <th className="py-3 px-4 text-right">Сумма (Работы + Запчасти)</th>
                <th className="py-3 px-4 text-center">Оплата</th>
                <th className="py-3 px-4 text-center">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/40 text-slate-200">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    По заданным критериям заказ-нарядов не найдено
                  </td>
                </tr>
              ) : (
                filteredOrders.map(order => {
                  const client = clients.find(c => c.id === order.clientId);
                  const car = cars.find(c => c.id === order.carId);
                  const { worksTotal, partsTotal, finalTotal } = calculateOrderTotals(order);
                  const statusObj = ORDER_STATUSES.find(s => s.label === order.status) || ORDER_STATUSES[0];

                  return (
                    <tr key={order.id} className="hover:bg-slate-700/30 transition-colors">
                      <td className="py-3.5 px-4 font-bold">
                        <span className="text-amber-400 cursor-pointer hover:underline" onClick={() => onOpenOrder(order.id)}>
                          {order.id}
                        </span>
                        <div className="text-[11px] text-slate-400 font-normal">{order.date}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-100">{client ? client.name : '—'}</div>
                        <div className="text-[11px] text-slate-400">{client ? client.phone : ''}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        {car ? (
                          <>
                            <div className="font-medium text-slate-100">{car.brand} {car.model}</div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              <span className="bg-slate-900 px-1 rounded border border-slate-700">{car.plateNumber}</span>
                            </div>
                          </>
                        ) : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {order.mechanic || 'Не назначен'}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${statusObj.color}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="font-bold text-slate-100 text-sm">{finalTotal.toLocaleString('ru-RU')} ₽</div>
                        <div className="text-[10px] text-slate-400">
                          Р: {worksTotal.toLocaleString('ru-RU')} | З: {partsTotal.toLocaleString('ru-RU')}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {order.isPaid ? (
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded-full">
                            <CheckCircle className="w-3 h-3" /> Оплачен ({order.paymentMethod || 'Касса'})
                          </span>
                        ) : (
                          <button
                            onClick={() => onPayOrderPrompt(order.id)}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] px-2.5 py-1 rounded cursor-pointer shadow transition-all"
                          >
                            Принять оплату
                          </button>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => onOpenOrder(order.id)}
                            title="Редактировать заказ"
                            className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onPrintOrder(order.id)}
                            title="Распечатать бланк"
                            className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-amber-400 cursor-pointer"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteOrder(order.id)}
                            title="Удалить"
                            className="p-1.5 bg-slate-700 hover:bg-rose-900 rounded text-slate-400 hover:text-rose-200 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// ВИД 3: КЛИЕНТЫ И АВТОМОБИЛИ (CRM)
// ==========================================
function ClientsView({ clients, cars, orders, searchQuery, setSearchQuery, onAddNewClient, onOpenOrder }) {
  const [selectedClientForView, setSelectedClientForView] = useState(null);

  const filteredClients = useMemo(() => {
    if (!searchQuery.trim()) return clients;
    const q = searchQuery.toLowerCase();
    return clients.filter(c => {
      const matchName = c.name.toLowerCase().includes(q);
      const matchPhone = c.phone.toLowerCase().includes(q);
      const clientCars = cars.filter(car => car.clientId === c.id);
      const matchCar = clientCars.some(car =>
        car.plateNumber.toLowerCase().includes(q) ||
        car.brand.toLowerCase().includes(q) ||
        car.model.toLowerCase().includes(q)
      );
      return matchName || matchPhone || matchCar;
    });
  }, [clients, cars, searchQuery]);

  return (
    <div className="space-y-4">
      {/* Верхняя строка действий */}
      <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-xl flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск по ФИО, телефону, госномеру автомобиля..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>
        <button
          onClick={onAddNewClient}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" />
          Добавить клиента и автомобиль
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Список клиентов */}
        <div className="lg:col-span-2 bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
          <div className="px-5 py-3.5 border-b border-slate-700/80">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-500" />
              База автовладельцев ({filteredClients.length})
            </h3>
          </div>
          <div className="divide-y divide-slate-700/50">
            {filteredClients.map(client => {
              const clientCars = cars.filter(c => c.clientId === client.id);
              const clientOrders = orders.filter(o => o.clientId === client.id);
              const isSelected = selectedClientForView?.id === client.id;

              return (
                <div
                  key={client.id}
                  onClick={() => setSelectedClientForView(client)}
                  className={`p-4 cursor-pointer transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                    isSelected ? 'bg-slate-700/60 border-l-4 border-amber-500' : 'hover:bg-slate-700/30'
                  }`}
                >
                  <div>
                    <div className="font-bold text-slate-100 text-sm flex items-center gap-2">
                      {client.name}
                    </div>
                    <div className="text-xs text-slate-400 flex items-center gap-3 mt-1">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3 text-amber-400" />
                        {client.phone}
                      </span>
                      {client.email && <span>{client.email}</span>}
                    </div>
                    {client.notes && (
                      <div className="text-[11px] text-slate-500 mt-1 italic">
                        Примечание: {client.notes}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-xs font-semibold text-slate-200">
                        {clientCars.length} авто
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Заказов: {clientOrders.length}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Детальная карточка выбранного клиента и его история */}
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm flex flex-col">
          <div className="px-5 py-3.5 border-b border-slate-700/80">
            <h3 className="text-sm font-semibold text-slate-100">
              Карточка клиента и история
            </h3>
          </div>

          {selectedClientForView ? (
            <div className="p-4 space-y-4 overflow-y-auto">
              <div>
                <h4 className="text-base font-bold text-amber-400">{selectedClientForView.name}</h4>
                <p className="text-xs text-slate-300 mt-1">Тел: {selectedClientForView.phone}</p>
                {selectedClientForView.notes && (
                  <p className="text-xs text-slate-400 bg-slate-900/60 p-2 rounded mt-2 border border-slate-700/50">
                    {selectedClientForView.notes}
                  </p>
                )}
              </div>

              {/* Привязанные авто */}
              <div>
                <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Car className="w-3.5 h-3.5 text-amber-400" />
                  Привязанные автомобили
                </h5>
                <div className="space-y-2">
                  {cars.filter(c => c.clientId === selectedClientForView.id).map(car => (
                    <div key={car.id} className="p-2.5 bg-slate-900 rounded-lg border border-slate-700/70 text-xs">
                      <div className="font-bold text-slate-100">{car.brand} {car.model} ({car.year} г.)</div>
                      <div className="text-amber-400 font-mono mt-0.5">{car.plateNumber}</div>
                      <div className="text-[10px] text-slate-400 mt-1">VIN: {car.vin || 'Не указан'}</div>
                      <div className="text-[10px] text-slate-400">Пробег: {car.mileage?.toLocaleString('ru-RU')} км</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* История заказ-нарядов */}
              <div>
                <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  История заказ-нарядов
                </h5>
                <div className="space-y-2">
                  {orders.filter(o => o.clientId === selectedClientForView.id).length === 0 ? (
                    <div className="text-xs text-slate-500 italic">Заказ-нарядов по клиенту пока нет</div>
                  ) : (
                    orders.filter(o => o.clientId === selectedClientForView.id).map(ord => (
                      <div
                        key={ord.id}
                        onClick={() => onOpenOrder(ord.id)}
                        className="p-2 bg-slate-900/90 hover:bg-slate-700/50 rounded border border-slate-700/50 cursor-pointer text-xs transition-colors flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-amber-400">{ord.id}</div>
                          <div className="text-[10px] text-slate-400">{ord.date} • {ord.status}</div>
                        </div>
                        <span className="text-[11px] font-bold text-slate-200">
                          {ord.isPaid ? 'Оплачен' : 'К оплате'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-400 flex flex-col items-center justify-center flex-1">
              <Users className="w-8 h-8 text-slate-600 mb-2" />
              Выберите клиента из списка слева, чтобы просмотреть привязанные автомобили и историю визитов
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// ВИД 4: СКЛАД ЗАПЧАСТЕЙ
// ==========================================
function WarehouseView({ parts, searchQuery, setSearchQuery, onAddNewPart, onQuickStockUpdate }) {
  const filteredParts = useMemo(() => {
    if (!searchQuery.trim()) return parts;
    const q = searchQuery.toLowerCase();
    return parts.filter(p =>
      p.article.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
    );
  }, [parts, searchQuery]);

  return (
    <div className="space-y-4">
      <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-xl flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск по артикулу, наименованию или категории..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>
        <button
          onClick={onAddNewPart}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" />
          Добавить запчасть / расходник
        </button>
      </div>

      <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-700/60">
              <tr>
                <th className="py-3 px-4">Артикул</th>
                <th className="py-3 px-4">Наименование номенклатуры</th>
                <th className="py-3 px-4">Категория</th>
                <th className="py-3 px-4 text-center">Остаток / Мин</th>
                <th className="py-3 px-4 text-right">Закупка</th>
                <th className="py-3 px-4 text-right">Розница</th>
                <th className="py-3 px-4 text-center">Быстрый приход/списание</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/40 text-slate-200">
              {filteredParts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    Запчастей по вашему запросу не найдено
                  </td>
                </tr>
              ) : (
                filteredParts.map(part => {
                  const isLow = part.stock <= part.minStock;
                  return (
                    <tr key={part.id} className="hover:bg-slate-700/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-amber-400">
                        {part.article}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-100">
                        {part.name}
                      </td>
                      <td className="py-3 px-4 text-slate-400">
                        <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-700/60 text-[11px]">
                          {part.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full font-bold text-xs ${
                          isLow ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-slate-900 text-emerald-400 border border-slate-700'
                        }`}>
                          {part.stock} шт.
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">мин: {part.minStock}</div>
                      </td>
                      <td className="py-3 px-4 text-right text-slate-400">
                        {part.costPrice.toLocaleString('ru-RU')} ₽
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-slate-100">
                        {part.sellPrice.toLocaleString('ru-RU')} ₽
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onQuickStockUpdate(part.id, -1)}
                            title="Списать 1 шт"
                            className="w-6 h-6 rounded bg-slate-700 hover:bg-slate-600 font-bold text-slate-200 flex items-center justify-center cursor-pointer"
                          >
                            -
                          </button>
                          <button
                            onClick={() => onQuickStockUpdate(part.id, 1)}
                            title="Приход +1 шт"
                            className="w-6 h-6 rounded bg-slate-700 hover:bg-slate-600 font-bold text-amber-400 flex items-center justify-center cursor-pointer"
                          >
                            +
                          </button>
                          <button
                            onClick={() => onQuickStockUpdate(part.id, 5)}
                            title="Приход упаковки (+5 шт)"
                            className="px-1.5 py-0.5 rounded bg-slate-700 hover:bg-slate-600 text-[10px] font-bold text-slate-300 cursor-pointer"
                          >
                            +5
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// ВИД 5: СПРАВОЧНИК УСЛУГ И НОРМОВРЕМЕНИ
// ==========================================
function ServicesView({ servicesCatalog, onAddNewService, onDeleteService }) {
  const [filterCat, setFilterCat] = useState('Все');

  const categories = useMemo(() => {
    const set = new Set(servicesCatalog.map(s => s.category));
    return ['Все', ...Array.from(set)];
  }, [servicesCatalog]);

  const filteredServices = useMemo(() => {
    if (filterCat === 'Все') return servicesCatalog;
    return servicesCatalog.filter(s => s.category === filterCat);
  }, [servicesCatalog, filterCat]);

  return (
    <div className="space-y-4">
      <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-xl flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilterCat(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer whitespace-nowrap transition-all ${
                filterCat === cat ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <button
          onClick={onAddNewService}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" />
          Добавить работу в каталог
        </button>
      </div>

      <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-700/60">
            <tr>
              <th className="py-3 px-4">Категория</th>
              <th className="py-3 px-4">Наименование автосервисной работы</th>
              <th className="py-3 px-4 text-center">Нормо-часы (н/ч)</th>
              <th className="py-3 px-4 text-right">Базовая стоимость</th>
              <th className="py-3 px-4 text-center">Действия</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/40 text-slate-200">
            {filteredServices.map(svc => (
              <tr key={svc.id} className="hover:bg-slate-700/30 transition-colors">
                <td className="py-3 px-4">
                  <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-700/60 text-[11px] text-slate-300">
                    {svc.category}
                  </span>
                </td>
                <td className="py-3 px-4 font-medium text-slate-100">
                  {svc.name}
                </td>
                <td className="py-3 px-4 text-center font-bold text-amber-400">
                  {svc.normHours} н/ч
                </td>
                <td className="py-3 px-4 text-right font-bold text-slate-100">
                  {svc.price.toLocaleString('ru-RU')} ₽
                </td>
                <td className="py-3 px-4 text-center">
                  <button
                    onClick={() => onDeleteService(svc.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 rounded cursor-pointer"
                    title="Удалить"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ==========================================
// ВИД 6: КАССА И ФИНАНСЫ
// ==========================================
function CashboxView({ transactions, orders, onAddExpense }) {
  const [expenseFormOpen, setExpenseFormOpen] = useState(false);
  const [newExpense, setNewExpense] = useState({
    amount: '',
    category: 'Хоз. расходы',
    method: 'Наличные',
    comment: ''
  });

  const totals = useMemo(() => {
    const inc = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const exp = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    return { inc, exp, balance: inc - exp };
  }, [transactions]);

  const handleSubmitExpense = (e) => {
    e.preventDefault();
    if (!newExpense.amount || Number(newExpense.amount) <= 0) return;
    onAddExpense(newExpense);
    setNewExpense({ amount: '', category: 'Хоз. расходы', method: 'Наличные', comment: '' });
    setExpenseFormOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Сводка баланса */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">ВСЕГО ПОСТУПЛЕНИЙ (ПРИХОД)</div>
          <div className="text-2xl font-bold text-emerald-400 mt-2">
            +{totals.inc.toLocaleString('ru-RU')} ₽
          </div>
        </div>
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">СЕРВИСНЫЕ РАСХОДЫ (РАСХОД)</div>
          <div className="text-2xl font-bold text-rose-400 mt-2">
            -{totals.exp.toLocaleString('ru-RU')} ₽
          </div>
        </div>
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">ОПЕРАЦИОННЫЙ ОСТАТОК КАССЫ</div>
          <div className={`text-2xl font-bold mt-2 ${totals.balance >= 0 ? 'text-amber-400' : 'text-rose-400'}`}>
            {totals.balance.toLocaleString('ru-RU')} ₽
          </div>
        </div>
      </div>

      {/* Панель добавления расхода */}
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wide">
          Журнал кассовых и безналичных операций
        </h3>
        <button
          onClick={() => setExpenseFormOpen(!expenseFormOpen)}
          className="bg-rose-700 hover:bg-rose-600 text-white font-semibold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 cursor-pointer shadow"
        >
          <Plus className="w-4 h-4" />
          Зафиксировать расход
        </button>
      </div>

      {expenseFormOpen && (
        <form onSubmit={handleSubmitExpense} className="bg-slate-800 border border-slate-700 p-4 rounded-xl space-y-3">
          <h4 className="text-xs font-bold text-rose-400 uppercase">Новый сервисный расход</h4>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Сумма (₽)*</label>
              <input
                type="number"
                required
                value={newExpense.amount}
                onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
                placeholder="0"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Категория</label>
              <select
                value={newExpense.category}
                onChange={(e) => setNewExpense({ ...newExpense, category: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
              >
                <option value="Хоз. расходы">Хоз. расходы</option>
                <option value="Инструмент и оборудование">Инструмент и оборудование</option>
                <option value="Аренда и коммуналка">Аренда и коммуналка</option>
                <option value="Закупка расходников цеха">Закупка расходников цеха</option>
                <option value="Зарплата мастерам">Зарплата мастерам</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Способ списания</label>
              <select
                value={newExpense.method}
                onChange={(e) => setNewExpense({ ...newExpense, method: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
              >
                <option value="Наличные">Наличные из кассы</option>
                <option value="Безналичный расчет">Безналичный расчет</option>
                <option value="Корп. Карта">Корп. Карта</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Комментарий / Назначение</label>
              <input
                type="text"
                value={newExpense.comment}
                onChange={(e) => setNewExpense({ ...newExpense, comment: e.target.value })}
                placeholder="За что списаны средства"
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setExpenseFormOpen(false)}
              className="px-3 py-1 rounded bg-slate-700 text-xs text-slate-300"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-1 rounded bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white shadow"
            >
              Списать сумму
            </button>
          </div>
        </form>
      )}

      {/* Таблица транзакций */}
      <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-700/60">
            <tr>
              <th className="py-3 px-4">Дата / Время</th>
              <th className="py-3 px-4">Тип</th>
              <th className="py-3 px-4">Сумма</th>
              <th className="py-3 px-4">Метод оплаты</th>
              <th className="py-3 px-4">Детали / Комментарий</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/40 text-slate-200">
            {transactions.map(tx => (
              <tr key={tx.id} className="hover:bg-slate-700/30 transition-colors">
                <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                  {tx.date}
                </td>
                <td className="py-3 px-4">
                  {tx.type === 'income' ? (
                    <span className="inline-block bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold">
                      Приход
                    </span>
                  ) : (
                    <span className="inline-block bg-rose-950 text-rose-400 border border-rose-800 px-2 py-0.5 rounded text-[10px] font-bold">
                      Расход
                    </span>
                  )}
                </td>
                <td className={`py-3 px-4 font-bold text-sm ${tx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {tx.type === 'income' ? '+' : '-'}{tx.amount.toLocaleString('ru-RU')} ₽
                </td>
                <td className="py-3 px-4 text-slate-300">
                  {tx.method}
                </td>
                <td className="py-3 px-4 text-slate-300">
                  {tx.comment}
                  {tx.orderId && (
                    <span className="ml-2 font-mono text-[10px] text-amber-400 bg-slate-900 px-1 py-0.5 rounded">
                      {tx.orderId}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ==========================================
// ВИД 7: НАСТРОЙКИ, РЕКВИЗИТЫ И БЭКАП
// ==========================================
function SettingsView({ company, onSaveCompany, onResetData, onExportData, onImportData }) {
  const [form, setForm] = useState({ ...company });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSaveCompany(form);
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-6 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
          <Settings className="w-4 h-4 text-amber-500" />
          Реквизиты автотехцентра для бланков Заказ-нарядов
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 mb-1">Название сервиса / СТО</label>
              <input
                type="text"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">ИНН / ОГРН</label>
              <input
                type="text"
                value={form.inn}
                onChange={e => setForm({ ...form, inn: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Фактический адрес сервиса</label>
              <input
                type="text"
                value={form.address}
                onChange={e => setForm({ ...form, address: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Контактный телефон СТО</label>
              <input
                type="text"
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Электронная почта</label>
              <input
                type="text"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Мастер-приемщик по умолчанию</label>
              <input
                type="text"
                value={form.master}
                onChange={e => setForm({ ...form, master: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>
          </div>
          <div className="pt-2">
            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-lg text-xs cursor-pointer shadow"
            >
              Сохранить реквизиты
            </button>
          </div>
        </form>
      </div>

      {/* Управление базой данных */}
      <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-6 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Резервное копирование и управление базой
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Все данные автоматически сохраняются в браузере (LocalStorage). Вы можете экспортировать полную копию данных в JSON файл для переноса или бэкапа.
        </p>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={onExportData}
            className="bg-slate-700 hover:bg-slate-600 text-white font-medium px-4 py-2 rounded-lg text-xs flex items-center gap-2 cursor-pointer shadow"
          >
            <Download className="w-4 h-4 text-amber-400" />
            Экспорт базы в JSON
          </button>

          <label className="bg-slate-700 hover:bg-slate-600 text-white font-medium px-4 py-2 rounded-lg text-xs flex items-center gap-2 cursor-pointer shadow">
            <Upload className="w-4 h-4 text-blue-400" />
            Импорт базы из JSON
            <input type="file" accept=".json" onChange={onImportData} className="hidden" />
          </label>

          <button
            onClick={onResetData}
            className="bg-rose-900/60 hover:bg-rose-900 text-rose-200 border border-rose-700 font-medium px-4 py-2 rounded-lg text-xs flex items-center gap-2 cursor-pointer ml-auto"
          >
            <RefreshCw className="w-4 h-4" />
            Сброс к демо-данным
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// МОДАЛЬНОЕ ОКНО: РЕДАКТИРОВАНИЕ ЗАКАЗ-НАРЯДА
// ==========================================
function OrderEditModal({ orderId, existingOrders, clients, cars, partsCatalog, servicesCatalog, company, onClose, onSave, onStockDeduct }) {
  const isNew = !orderId;
  const existing = existingOrders.find(o => o.id === orderId);

  const [order, setOrder] = useState(() => {
    if (existing) {
      return JSON.parse(JSON.stringify(existing));
    }
    const today = new Date().toISOString().split('T')[0];
    const newNum = `ЗН-${new Date().getFullYear()}-${String(existingOrders.length + 1).padStart(3, '0')}`;
    return {
      id: newNum,
      date: today,
      clientId: clients[0]?.id || '',
      carId: cars.find(c => c.clientId === clients[0]?.id)?.id || cars[0]?.id || '',
      status: 'Принят',
      reason: '',
      recommendations: '',
      mechanic: company.master || 'Мастер-приемщик',
      works: [],
      partsUsed: [],
      discountPercent: 0,
      isPaid: false,
      paymentMethod: null
    };
  });

  // Фильтруем автомобили выбранного клиента
  const availableCars = useMemo(() => {
    return cars.filter(c => c.clientId === order.clientId);
  }, [cars, order.clientId]);

  // Быстрый выбор услуги из справочника
  const handleAddServiceFromCatalog = (serviceId) => {
    const svc = servicesCatalog.find(s => s.id === serviceId);
    if (!svc) return;
    const newWork = {
      id: `w-${Date.now()}`,
      name: svc.name,
      normHours: svc.normHours,
      price: svc.price,
      master: order.mechanic || 'Мастер',
      total: svc.price
    };
    setOrder(prev => ({ ...prev, works: [...prev.works, newWork] }));
  };

  // Ручное добавление работы
  const handleAddCustomWork = () => {
    const newWork = {
      id: `w-${Date.now()}`,
      name: 'Новая работа / диагностика',
      normHours: 1.0,
      price: 1500,
      master: order.mechanic || 'Мастер',
      total: 1500
    };
    setOrder(prev => ({ ...prev, works: [...prev.works, newWork] }));
  };

  // Удаление работы
  const handleRemoveWork = (workId) => {
    setOrder(prev => ({ ...prev, works: prev.works.filter(w => w.id !== workId) }));
  };

  // Изменение работы
  const handleWorkChange = (workId, field, val) => {
    setOrder(prev => ({
      ...prev,
      works: prev.works.map(w => {
        if (w.id === workId) {
          const updated = { ...w, [field]: val };
          if (field === 'price' || field === 'normHours') {
            updated.total = Number(updated.price) || 0;
          }
          return updated;
        }
        return w;
      })
    }));
  };

  // Добавление запчасти со склада
  const handleAddPartFromStock = (partId) => {
    const p = partsCatalog.find(item => item.id === partId);
    if (!p) return;
    if (p.stock < 1) {
      alert(`Внимание: детали «${p.name}» нет в достаточном количестве на складе.`);
    }
    const newPart = {
      id: `pu-${Date.now()}`,
      partId: p.id,
      article: p.article,
      name: p.name,
      count: 1,
      price: p.sellPrice,
      total: p.sellPrice
    };
    setOrder(prev => ({ ...prev, partsUsed: [...prev.partsUsed, newPart] }));
  };

  // Удаление запчасти
  const handleRemovePart = (partItemId) => {
    setOrder(prev => ({ ...prev, partsUsed: prev.partsUsed.filter(p => p.id !== partItemId) }));
  };

  // Изменение запчасти
  const handlePartChange = (partItemId, field, val) => {
    setOrder(prev => ({
      ...prev,
      partsUsed: prev.partsUsed.map(p => {
        if (p.id === partItemId) {
          const updated = { ...p, [field]: val };
          const count = Number(field === 'count' ? val : updated.count) || 0;
          const price = Number(field === 'price' ? val : updated.price) || 0;
          updated.total = count * price;
          return updated;
        }
        return p;
      })
    }));
  };

  // Итоги
  const worksSum = order.works.reduce((acc, w) => acc + (Number(w.total) || 0), 0);
  const partsSum = order.partsUsed.reduce((acc, p) => acc + (Number(p.total) || 0), 0);
  const rawSum = worksSum + partsSum;
  const discountAmount = Math.round((rawSum * (Number(order.discountPercent) || 0)) / 100);
  const finalSum = rawSum - discountAmount;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!order.clientId) {
      alert('Пожалуйста, выберите клиента.');
      return;
    }
    onSave(order);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Заголовок */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                {isNew ? 'Оформление заказ-наряда' : `Заказ-наряд ${order.id}`}
                <span className="text-xs font-normal text-slate-400 font-mono">({order.date})</span>
              </h2>
              <p className="text-xs text-slate-400">Форма приёмки и учета выполненных работ</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Тело формы */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Секция 1: Данные по клиенту и авто */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-800/40 p-4 rounded-xl border border-slate-700/60">
            <div>
              <label className="block text-slate-400 mb-1 font-semibold">Клиент (Заказчик)*</label>
              <select
                value={order.clientId}
                onChange={e => {
                  const newCId = e.target.value;
                  const firstCar = cars.find(c => c.clientId === newCId);
                  setOrder({ ...order, clientId: newCId, carId: firstCar ? firstCar.id : '' });
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
              >
                {clients.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.phone})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold">Автомобиль*</label>
              <select
                value={order.carId}
                onChange={e => setOrder({ ...order, carId: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
              >
                {availableCars.length === 0 ? (
                  <option value="">Нет привязанных авто</option>
                ) : (
                  availableCars.map(c => (
                    <option key={c.id} value={c.id}>{c.brand} {c.model} - {c.plateNumber}</option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold">Мастер-приемщик / Пост</label>
              <input
                type="text"
                value={order.mechanic}
                onChange={e => setOrder({ ...order, mechanic: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold">Текущий статус наряда</label>
              <select
                value={order.status}
                onChange={e => setOrder({ ...order, status: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-amber-400 font-bold"
              >
                {ORDER_STATUSES.map(s => (
                  <option key={s.label} value={s.label}>{s.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Причина обращения и рекомендации */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Причина обращения / Жалобы заказчика</label>
              <textarea
                rows={2}
                value={order.reason}
                onChange={e => setOrder({ ...order, reason: e.target.value })}
                placeholder="Стук в подвеске, замена масла, свист тормозов при торможении..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-medium mb-1">Рекомендации мастера и дефектовка</label>
              <textarea
                rows={2}
                value={order.recommendations}
                onChange={e => setOrder({ ...order, recommendations: e.target.value })}
                placeholder="Рекомендована замена задних тормозных колодок через 5 000 км..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500"
              />
            </div>
          </div>

          {/* ТАБЛИЦА 1: ВЫПОЛНЕННЫЕ РАБОТЫ */}
          <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-400" />
                Выполненные работы и услуги ({order.works.length})
              </h3>
              <div className="flex items-center gap-2">
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      handleAddServiceFromCatalog(e.target.value);
                      e.target.value = '';
                    }
                  }}
                  className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-300"
                  defaultValue=""
                >
                  <option value="" disabled>+ Из каталога услуг...</option>
                  {servicesCatalog.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.price} ₽)</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={handleAddCustomWork}
                  className="bg-slate-700 hover:bg-slate-600 text-slate-200 px-2.5 py-1 rounded font-medium"
                >
                  + Своя строка
                </button>
              </div>
            </div>

            <table className="w-full text-left text-xs">
              <thead className="text-slate-400 border-b border-slate-700/60 pb-1">
                <tr>
                  <th className="py-1.5">Наименование услуги</th>
                  <th className="py-1.5 w-20 text-center">Н/ч</th>
                  <th className="py-1.5 w-24 text-right">Стоимость, ₽</th>
                  <th className="py-1.5 w-32">Исполнитель</th>
                  <th className="py-1.5 w-24 text-right">Итого, ₽</th>
                  <th className="py-1.5 w-10 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {order.works.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-3 text-center text-slate-500 italic">Работы еще не добавлены</td>
                  </tr>
                ) : (
                  order.works.map(w => (
                    <tr key={w.id}>
                      <td className="py-1.5 pr-2">
                        <input
                          type="text"
                          value={w.name}
                          onChange={e => handleWorkChange(w.id, 'name', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <input
                          type="number"
                          step="0.1"
                          value={w.normHours}
                          onChange={e => handleWorkChange(w.id, 'normHours', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-1 py-1 text-center text-white"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <input
                          type="number"
                          value={w.price}
                          onChange={e => handleWorkChange(w.id, 'price', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-right text-white"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <input
                          type="text"
                          value={w.master}
                          onChange={e => handleWorkChange(w.id, 'master', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                      </td>
                      <td className="py-1.5 pl-2 text-right font-bold text-amber-400">
                        {w.total.toLocaleString('ru-RU')} ₽
                      </td>
                      <td className="py-1.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveWork(w.id)}
                          className="text-slate-500 hover:text-rose-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="text-right text-xs text-slate-400 pt-1">
              Итого за работы: <span className="font-bold text-white">{worksSum.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          {/* ТАБЛИЦА 2: ЗАПАСНЫЕ ЧАСТИ И МАТЕРИАЛЫ */}
          <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                <Package className="w-4 h-4 text-emerald-400" />
                Запасные части и технические жидкости ({order.partsUsed.length})
              </h3>
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    handleAddPartFromStock(e.target.value);
                    e.target.value = '';
                  }
                }}
                className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-300"
                defaultValue=""
              >
                <option value="" disabled>+ Подобрать со склада...</option>
                {partsCatalog.map(p => (
                  <option key={p.id} value={p.id}>
                    [{p.article}] {p.name} (ост. {p.stock} шт) - {p.sellPrice} ₽
                  </option>
                ))}
              </select>
            </div>

            <table className="w-full text-left text-xs">
              <thead className="text-slate-400 border-b border-slate-700/60 pb-1">
                <tr>
                  <th className="py-1.5 w-28">Артикул</th>
                  <th className="py-1.5">Наименование детали / жидкости</th>
                  <th className="py-1.5 w-20 text-center">Кол-во</th>
                  <th className="py-1.5 w-24 text-right">Цена, ₽</th>
                  <th className="py-1.5 w-24 text-right">Сумма, ₽</th>
                  <th className="py-1.5 w-10 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {order.partsUsed.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-3 text-center text-slate-500 italic">Запчасти не включены</td>
                  </tr>
                ) : (
                  order.partsUsed.map(p => (
                    <tr key={p.id}>
                      <td className="py-1.5 pr-2 font-mono text-amber-400">
                        <input
                          type="text"
                          value={p.article}
                          onChange={e => handlePartChange(p.id, 'article', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <input
                          type="text"
                          value={p.name}
                          onChange={e => handlePartChange(p.id, 'name', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <input
                          type="number"
                          min="1"
                          value={p.count}
                          onChange={e => handlePartChange(p.id, 'count', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-1 py-1 text-center text-white"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <input
                          type="number"
                          value={p.price}
                          onChange={e => handlePartChange(p.id, 'price', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-right text-white"
                        />
                      </td>
                      <td className="py-1.5 pl-2 text-right font-bold text-emerald-400">
                        {p.total.toLocaleString('ru-RU')} ₽
                      </td>
                      <td className="py-1.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemovePart(p.id)}
                          className="text-slate-500 hover:text-rose-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="text-right text-xs text-slate-400 pt-1">
              Итого за запчасти: <span className="font-bold text-white">{partsSum.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          {/* ИТОГОВЫЙ БЛОК РАСЧЕТА */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <label className="block text-slate-400 mb-1">Скидка клиента (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={order.discountPercent}
                  onChange={e => setOrder({ ...order, discountPercent: Number(e.target.value) || 0 })}
                  className="w-24 bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-center font-bold text-amber-400"
                />
              </div>
              <div className="text-xs text-slate-400">
                <div>Сумма без скидки: <span className="text-white font-medium">{rawSum.toLocaleString('ru-RU')} ₽</span></div>
                <div>Скидка: <span className="text-amber-400 font-medium">-{discountAmount.toLocaleString('ru-RU')} ₽</span></div>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">ИТОГО К ОПЛАТЕ:</span>
              <span className="text-2xl font-black text-amber-400">{finalSum.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 font-medium cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg cursor-pointer shadow-lg shadow-amber-500/20"
            >
              Сохранить заказ-наряд
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// ПЕЧАТНАЯ ФОРМА: ОФИЦИАЛЬНЫЙ БЛАНК ЗАКАЗ-НАРЯДА (ГОСТ)
// ==========================================
function OrderPrintModal({ order, client, car, company, calculateOrderTotals, onClose }) {
  const printRef = useRef();
  const { worksTotal, partsTotal, rawTotal, discount, finalTotal } = calculateOrderTotals(order);

  const handlePrint = () => {
    const original = document.getElementById('printable-area');
    if (!original) return;
    // Build two independent A4 copies for printing without changing the preview.
    document.getElementById('order-print-copies')?.remove();
    const printRoot = document.createElement('div');
    printRoot.id = 'order-print-copies';
    printRoot.className = 'order-print-copies';
    ['Экземпляр Клиента', 'Экземпляр Исполнителя'].forEach((label) => {
      const copy = original.cloneNode(true);
      copy.removeAttribute('id');
      const badge = copy.querySelector('.order-copy-label');
      if (badge) badge.textContent = label;
      printRoot.appendChild(copy);
    });
    document.body.appendChild(printRoot);
    const cleanup = () => {
      printRoot.remove();
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup, { once: true });
    window.print();
    // Fallback for environments that don't fire afterprint.
    setTimeout(cleanup, 60000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl flex flex-col max-h-[96vh]">
        {/* Кнопки управления печатью */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between no-print">
          <div className="flex items-center gap-2 text-slate-200 text-sm font-semibold">
            <Printer className="w-4 h-4 text-amber-400" />
            Предварительный просмотр бланка «Заказ-наряд» (ГОСТ/АвтоДилер)
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-1.5 rounded-lg text-xs flex items-center gap-1.5 cursor-pointer shadow"
            >
              <Printer className="w-4 h-4" />
              Распечатать документ
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Лист А4 для печати (Светлый стиль бланка) */}
        <div className="p-8 overflow-y-auto bg-slate-800 flex justify-center">
          <div
            ref={printRef}
            className="w-full max-w-[210mm] min-h-[297mm] bg-white text-black p-8 text-[11px] font-sans leading-tight shadow-2xl print:m-0 print:p-6 print:shadow-none"
            id="printable-area"
          >
            {/* Шапка автосервиса */}
            <div className="border-b-2 border-black pb-3 mb-3 flex justify-between items-start">
              <div>
                <h1 className="text-base font-black uppercase tracking-wide">{company.name}</h1>
                <p className="text-[10px] text-gray-700">{company.address}</p>
                <p className="text-[10px] text-gray-700">ИНН: {company.inn} | Тел: {company.phone} | Email: {company.email}</p>
              </div>
              <div className="text-right">
                <div className="order-copy-label text-xs font-bold border border-black px-2 py-1 inline-block">
                  Экземпляр Клиента
                </div>
              </div>
            </div>

            {/* Номер и дата наряда */}
            <div className="text-center my-3">
              <h2 className="text-sm font-bold uppercase tracking-wider">
                ЗАКАЗ-НАРЯД № {order.id} от {order.date} г.
              </h2>
            </div>

            {/* Таблица реквизитов заказчика и ТС */}
            <div className="border border-black mb-3">
              <div className="grid grid-cols-2 divide-x divide-black border-b border-black p-1.5 bg-gray-100 font-bold text-[10px]">
                <div>ЗАКАЗЧИК (ВЛАДЕЛЕЦ ТС)</div>
                <div>СВЕДЕНИЯ ОБ АВТОМОБИЛЕ</div>
              </div>
              <div className="grid grid-cols-2 divide-x divide-black p-2 gap-2">
                <div className="space-y-0.5">
                  <div><span className="font-semibold">ФИО / Орг:</span> {client?.name || '—'}</div>
                  <div><span className="font-semibold">Телефон:</span> {client?.phone || '—'}</div>
                  {client?.notes && <div><span className="font-semibold">Примечание:</span> {client.notes}</div>}
                </div>
                <div className="space-y-0.5">
                  <div><span className="font-semibold">Марка, модель:</span> {car ? `${car.brand} ${car.model}` : '—'}</div>
                  <div><span className="font-semibold">Гос. рег. знак:</span> <span className="font-bold uppercase">{car?.plateNumber || '—'}</span></div>
                  <div><span className="font-semibold">VIN:</span> {car?.vin || 'Не указан'}</div>
                  <div><span className="font-semibold">Год / Пробег:</span> {car?.year || '—'} г. / {car?.mileage ? `${car.mileage} км` : '—'}</div>
                </div>
              </div>
            </div>

            {/* Причина обращения */}
            {order.reason && (
              <div className="border border-black p-2 mb-3 bg-gray-50">
                <span className="font-bold">Причина обращения / Заявленная неисправность:</span> {order.reason}
              </div>
            )}

            {/* Таблица 1: Выполненные работы */}
            <div className="mb-3">
              <div className="font-bold text-[11px] uppercase mb-1">1. Выполненные работы и услуги</div>
              <table className="w-full border-collapse border border-black text-[10px]">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-black p-1 text-center w-6">№</th>
                    <th className="border border-black p-1 text-left">Наименование работы</th>
                    <th className="border border-black p-1 text-center w-12">Н/ч</th>
                    <th className="border border-black p-1 text-right w-16">Цена, ₽</th>
                    <th className="border border-black p-1 text-left w-24">Исполнитель</th>
                    <th className="border border-black p-1 text-right w-16">Сумма, ₽</th>
                  </tr>
                </thead>
                <tbody>
                  {order.works.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="border border-black p-1 text-center italic text-gray-500">Работы не выполнялись</td>
                    </tr>
                  ) : (
                    order.works.map((w, idx) => (
                      <tr key={w.id}>
                        <td className="border border-black p-1 text-center">{idx + 1}</td>
                        <td className="border border-black p-1">{w.name}</td>
                        <td className="border border-black p-1 text-center">{w.normHours}</td>
                        <td className="border border-black p-1 text-right">{Number(w.price).toLocaleString('ru-RU')}</td>
                        <td className="border border-black p-1">{w.master || '—'}</td>
                        <td className="border border-black p-1 text-right font-medium">{Number(w.total).toLocaleString('ru-RU')}</td>
                      </tr>
                    ))
                  )}
                  <tr className="font-bold bg-gray-50">
                    <td colSpan={5} className="border border-black p-1 text-right">Итого по разделу 1 (работы):</td>
                    <td className="border border-black p-1 text-right">{worksTotal.toLocaleString('ru-RU')} ₽</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Таблица 2: Использованные запасные части */}
            <div className="mb-3">
              <div className="font-bold text-[11px] uppercase mb-1">2. Запасные части и материалы исполнителя</div>
              <table className="w-full border-collapse border border-black text-[10px]">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-black p-1 text-center w-6">№</th>
                    <th className="border border-black p-1 text-center w-20">Артикул</th>
                    <th className="border border-black p-1 text-left">Наименование запчасти / жидкости</th>
                    <th className="border border-black p-1 text-center w-12">Кол-во</th>
                    <th className="border border-black p-1 text-right w-16">Цена, ₽</th>
                    <th className="border border-black p-1 text-right w-16">Сумма, ₽</th>
                  </tr>
                </thead>
                <tbody>
                  {order.partsUsed.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="border border-black p-1 text-center italic text-gray-500">Запчасти не использовались</td>
                    </tr>
                  ) : (
                    order.partsUsed.map((p, idx) => (
                      <tr key={p.id}>
                        <td className="border border-black p-1 text-center">{idx + 1}</td>
                        <td className="border border-black p-1 text-center font-mono">{p.article}</td>
                        <td className="border border-black p-1">{p.name}</td>
                        <td className="border border-black p-1 text-center">{p.count} шт</td>
                        <td className="border border-black p-1 text-right">{Number(p.price).toLocaleString('ru-RU')}</td>
                        <td className="border border-black p-1 text-right font-medium">{Number(p.total).toLocaleString('ru-RU')}</td>
                      </tr>
                    ))
                  )}
                  <tr className="font-bold bg-gray-50">
                    <td colSpan={5} className="border border-black p-1 text-right">Итого по разделу 2 (запчасти):</td>
                    <td className="border border-black p-1 text-right">{partsTotal.toLocaleString('ru-RU')} ₽</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Итоговый расчет */}
            <div className="border border-black p-2 mb-3 bg-gray-50 flex justify-between items-center text-xs">
              <div>
                {order.discountPercent > 0 && (
                  <div>Скидка: <span className="font-bold">{order.discountPercent}%</span> ({discount.toLocaleString('ru-RU')} ₽)</div>
                )}
                <div>Мастер-приемщик: <span className="font-bold">{order.mechanic || company.master}</span></div>
              </div>
              <div className="text-right">
                <div className="text-sm font-black">
                  ИТОГО К ОПЛАТЕ: {finalTotal.toLocaleString('ru-RU')} руб. 00 коп.
                </div>
                <div className="text-[10px] text-gray-600">
                  {order.isPaid ? `(Оплачено в полном объеме: ${order.paymentMethod || 'касса'})` : '(Ожидает оплаты)'}
                </div>
              </div>
            </div>

            {/* Рекомендации */}
            {order.recommendations && (
              <div className="border border-black p-2 mb-3 text-[10px]">
                <span className="font-bold">Рекомендации и особые отметки сервиса:</span> {order.recommendations}
              </div>
            )}

            {/* Гарантийные условия и подписи сторон */}
            <div className="text-[9px] text-gray-600 border border-black p-2 mb-4 leading-normal">
              <strong>Гарантийные обязательства:</strong> Гарантия на выполненные слесарные работы составляет 30 дней или 1 000 км пробега (в зависимости от того, что наступит ранее). Гарантия на оригинальные запасные части — согласно условиям завода-изготовителя. Претензии по внешнему виду, комплектности и сохранности деталей принимаются непосредственно при получении автомобиля.
            </div>

            <div className="grid grid-cols-2 gap-8 text-[10px] pt-2">
              <div className="border-t border-black pt-1">
                <p>Работу сдал (Исполнитель):</p>
                <p className="mt-4 text-gray-500">_________________ / {company.master} /</p>
                <p className="text-[8px] text-gray-400 mt-1">М.П.</p>
              </div>
              <div className="border-t border-black pt-1">
                <p>Автомобиль принял, претензий по объему, качеству и срокам работ не имею (Заказчик):</p>
                <p className="mt-4 text-gray-500">_________________ / {client?.name || 'Клиент'} /</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// МОДАЛЬНОЕ ОКНО: ДОБАВЛЕНИЕ КЛИЕНТА + АВТО
// ==========================================
function NewClientModal({ onClose, onSave }) {
  const [client, setClient] = useState({ name: '', phone: '', email: '', notes: '' });
  const [car, setCar] = useState({ brand: '', model: '', plateNumber: '', vin: '', year: 2021, mileage: 50000, color: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!client.name.trim() || !client.phone.trim()) {
      alert('Заполните ФИО и телефон клиента');
      return;
    }
    if (!car.brand.trim() || !car.model.trim()) {
      alert('Заполните марку и модель автомобиля');
      return;
    }
    onSave(client, car);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-500" />
            Регистрация нового клиента и его автомобиля
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Данные клиента */}
          <div>
            <h3 className="font-bold text-amber-400 mb-2 uppercase text-[10px] tracking-wider">1. Контакты владельца</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">ФИО клиента / Название компании*</label>
                <input
                  type="text"
                  required
                  placeholder="Иванов Иван Иванович"
                  value={client.name}
                  onChange={e => setClient({ ...client, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Номер телефона*</label>
                <input
                  type="tel"
                  required
                  placeholder="+7 (999) 000-00-00"
                  value={client.phone}
                  onChange={e => setClient({ ...client, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Email</label>
                <input
                  type="email"
                  placeholder="client@mail.ru"
                  value={client.email}
                  onChange={e => setClient({ ...client, email: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Заметка / Примечание</label>
                <input
                  type="text"
                  placeholder="Постоянный клиент, скидка 5%"
                  value={client.notes}
                  onChange={e => setClient({ ...client, notes: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
            </div>
          </div>

          {/* Данные авто */}
          <div className="border-t border-slate-800 pt-3">
            <h3 className="font-bold text-amber-400 mb-2 uppercase text-[10px] tracking-wider">2. Данные автомобиля</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Марка*</label>
                <input
                  type="text"
                  required
                  placeholder="Toyota, BMW, Lada"
                  value={car.brand}
                  onChange={e => setCar({ ...car, brand: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Модель*</label>
                <input
                  type="text"
                  required
                  placeholder="Camry, X5, Vesta"
                  value={car.model}
                  onChange={e => setCar({ ...car, model: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Гос. номер</label>
                <input
                  type="text"
                  placeholder="А777АА 777"
                  value={car.plateNumber}
                  onChange={e => setCar({ ...car, plateNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white uppercase font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">VIN-номер</label>
                <input
                  type="text"
                  placeholder="17 символов"
                  value={car.vin}
                  onChange={e => setCar({ ...car, vin: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono uppercase"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Год выпуска</label>
                <input
                  type="number"
                  value={car.year}
                  onChange={e => setCar({ ...car, year: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Текущий пробег (км)</label>
                <input
                  type="number"
                  value={car.mileage}
                  onChange={e => setCar({ ...car, mileage: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 rounded text-slate-300 font-medium cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded cursor-pointer shadow"
            >
              Зарегистрировать
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// МОДАЛЬНОЕ ОКНО: НОВАЯ ЗАПЧАСТЬ
// ==========================================
function NewPartModal({ onClose, onSave }) {
  const [form, setForm] = useState({
    article: '',
    name: '',
    category: 'Фильтры',
    stock: 5,
    minStock: 2,
    costPrice: 500,
    sellPrice: 1000
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.article.trim() || !form.name.trim()) {
      alert('Заполните артикул и наименование детали');
      return;
    }
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Package className="w-4 h-4 text-amber-500" />
            Оприходование детали в складской каталог
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">Артикул / Каталожный номер*</label>
            <input
              type="text"
              required
              placeholder="например: OC470 или 5W40-MOTUL"
              value={form.article}
              onChange={e => setForm({ ...form, article: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-amber-400 font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Наименование детали / расходника*</label>
            <input
              type="text"
              required
              placeholder="Фильтр масляный VAG 1.6 / 1.4 TSI"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Категория запчасти</label>
            <select
              value={form.category}
              onChange={e => setForm({ ...form, category: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
            >
              <option value="Фильтры">Фильтры</option>
              <option value="Масла и тех. жидкости">Масла и тех. жидкости</option>
              <option value="Тормозная система">Тормозная система</option>
              <option value="Подвеска и рулевое">Подвеска и рулевое</option>
              <option value="Двигатель">Двигатель</option>
              <option value="Автохимия">Автохимия</option>
              <option value="Электрика и свет">Электрика и свет</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 mb-1">Количество на складе (шт)*</label>
              <input
                type="number"
                min="0"
                value={form.stock}
                onChange={e => setForm({ ...form, stock: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Минимальный остаток (дефицит)</label>
              <input
                type="number"
                min="0"
                value={form.minStock}
                onChange={e => setForm({ ...form, minStock: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 mb-1">Закупочная цена (₽)</label>
              <input
                type="number"
                value={form.costPrice}
                onChange={e => setForm({ ...form, costPrice: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Розничная цена продажи (₽)*</label>
              <input
                type="number"
                value={form.sellPrice}
                onChange={e => setForm({ ...form, sellPrice: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-amber-400 font-bold"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 rounded text-slate-300 font-medium cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded cursor-pointer shadow"
            >
              Добавить на склад
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// МОДАЛЬНОЕ ОКНО: НОВАЯ УСЛУГА В КАТАЛОГ
// ==========================================
function NewServiceModal({ onClose, onSave }) {
  const [form, setForm] = useState({
    category: 'Техническое обслуживание',
    name: '',
    normHours: 1.0,
    price: 2000
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-500" />
            Добавить услугу в справочник работ
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">Категория работ</label>
            <input
              type="text"
              value={form.category}
              onChange={e => setForm({ ...form, category: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Наименование работы / операции*</label>
            <input
              type="text"
              required
              placeholder="например: Замена свечей зажигания (4 шт)"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 mb-1">Нормо-часы (н/ч)</label>
              <input
                type="number"
                step="0.1"
                value={form.normHours}
                onChange={e => setForm({ ...form, normHours: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Базовая стоимость (₽)*</label>
              <input
                type="number"
                value={form.price}
                onChange={e => setForm({ ...form, price: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-amber-400 font-bold"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 rounded text-slate-300 font-medium cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded cursor-pointer shadow"
            >
              Сохранить
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// МОДАЛЬНОЕ ОКНО: ЧЕК ОБ ОПЛАТЕ
// ==========================================
function PaymentReceiptModal({ receipt, onClose }) {
  const money = Number(receipt?.amount || 0).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const printReceipt = () => {
    const popup = window.open('', 'autodealer-payment-receipt', 'width=760,height=850,resizable=yes,scrollbars=yes');
    if (!popup) {
      alert('Окно печати заблокировано. Разрешите всплывающие окна и попробуйте ещё раз.');
      return;
    }
    const r = receipt;
    popup.document.open();
    popup.document.write(`<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Чек об оплате ${esc(r.receiptNo)}</title><style>body{font:14px Arial,sans-serif;color:#111;background:#eee;margin:0}.toolbar{padding:12px;background:#263244;text-align:right;position:sticky;top:0}.toolbar button{padding:9px 16px;margin-left:8px;cursor:pointer}.paper{background:#fff;width:680px;max-width:calc(100% - 40px);margin:20px auto;padding:28px;box-sizing:border-box;border:1px solid #ddd}.center{text-align:center}.muted{color:#555;font-size:12px}.row{display:flex;justify-content:space-between;gap:16px;padding:8px 0;border-bottom:1px dashed #bbb}.total{font-size:22px;font-weight:bold}.foot{margin-top:24px;border-top:1px solid #aaa;padding-top:12px;font-size:12px}@media print{body{background:#fff}.toolbar{display:none}.paper{width:auto;max-width:none;margin:0;border:0;padding:0}@page{size:A5 portrait;margin:12mm}}</style></head><body><div class="toolbar"><button onclick="window.close()">Закрыть</button><button onclick="window.print()">Печать чека</button></div><main class="paper"><h2 class="center">${esc(r.company?.name || 'АвтоДилер')}</h2><p class="center muted">${esc(r.company?.address || '')}${r.company?.phone ? '<br>Тел.: '+esc(r.company.phone) : ''}${r.company?.inn ? '<br>ИНН: '+esc(r.company.inn) : ''}</p><hr><h2 class="center">ЧЕК ОБ ОПЛАТЕ</h2><p class="center muted">№ ${esc(r.receiptNo)} · ${esc(r.date)}</p><div class="row"><span>Заказ-наряд</span><b>№ ${esc(r.orderId)}</b></div><div class="row"><span>Клиент</span><b>${esc(r.clientName)}</b></div>${r.clientPhone ? `<div class="row"><span>Телефон клиента</span><b>${esc(r.clientPhone)}</b></div>` : ''}<div class="row"><span>Автомобиль</span><b>${esc(r.carName)}</b></div>${r.plateNumber ? `<div class="row"><span>Госномер</span><b>${esc(r.plateNumber)}</b></div>` : ''}${r.vin ? `<div class="row"><span>VIN</span><b>${esc(r.vin)}</b></div>` : ''}<div class="row"><span>Способ оплаты</span><b>${esc(r.method)}</b></div><div class="row"><span>Итого получено</span><span class="total">${money} ₽</span></div><p class="muted">Операция: ${esc(r.transactionId)}</p><div class="foot"><p>Оплата по заказ-наряду принята. Сохраните этот документ для подтверждения расчёта.</p><p>Этот документ сформирован программой автосервиса и сам по себе не является фискальным кассовым чеком ККТ.</p><p>Подпись кассира: ____________________</p></div></main></body></html>`);
    popup.document.close();
    popup.focus();
  };
  return (
    <div className="fixed inset-0 z-[70] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-lg max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-slate-800"><div><h2 className="text-lg font-bold text-white flex items-center gap-2"><CheckCircle className="w-5 h-5 text-emerald-400"/> Оплата принята</h2><p className="text-xs text-slate-400 mt-1">Предпросмотр документа об оплате</p></div><button onClick={onClose} className="text-slate-400 hover:text-white" aria-label="Закрыть"><X className="w-5 h-5"/></button></div>
        <div className="p-5"><div className="bg-white text-slate-900 rounded-lg p-6 border border-slate-300"><div className="text-center"><div className="font-bold text-lg">{receipt.company?.name || 'АвтоДилер'}</div><div className="text-xs text-slate-500">{receipt.company?.address || ''}</div><h3 className="font-black text-xl mt-5">ЧЕК ОБ ОПЛАТЕ</h3><div className="text-xs text-slate-500 mt-1">№ {receipt.receiptNo} · {receipt.date}</div></div><div className="border-t border-dashed border-slate-400 my-4"/><div className="space-y-3 text-sm"><div className="flex justify-between gap-3"><span>Заказ-наряд</span><b>№ {receipt.orderId}</b></div><div className="flex justify-between gap-3"><span>Клиент</span><b className="text-right">{receipt.clientName}</b></div><div className="flex justify-between gap-3"><span>Автомобиль</span><b className="text-right">{receipt.carName}</b></div>{receipt.plateNumber && <div className="flex justify-between gap-3"><span>Госномер</span><b>{receipt.plateNumber}</b></div>}<div className="flex justify-between gap-3"><span>Способ оплаты</span><b>{receipt.method}</b></div></div><div className="border-t border-dashed border-slate-400 my-4"/><div className="flex items-end justify-between gap-3"><span className="font-semibold">Получено</span><strong className="text-2xl">{money} ₽</strong></div><p className="text-[11px] text-slate-500 mt-4">Документ об оплате, сформированный программой автосервиса. Не является фискальным чеком ККТ.</p></div><div className="flex flex-wrap justify-end gap-2 mt-5"><button onClick={onClose} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200">Закрыть</button><button onClick={printReceipt} className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-2"><Printer className="w-4 h-4"/> Печать чека</button></div></div>
      </div>
    </div>
  );
}

// ==========================================
// МОДАЛЬНОЕ ОКНО: ОПЛАТА ЗАКАЗ-НАРЯДА
// ==========================================
function PaymentModal({ order, calculateOrderTotals, onClose, onConfirm }) {
  const [method, setMethod] = useState('Наличные');
  const { finalTotal } = calculateOrderTotals(order);

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            Приём оплаты по заказ-наряду {order.id}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
            <div className="text-slate-400 text-xs">Итоговая сумма к оплате:</div>
            <div className="text-3xl font-black text-emerald-400 mt-1">
              {finalTotal.toLocaleString('ru-RU')} ₽
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-2">Выберите способ оплаты:</label>
            <div className="grid grid-cols-3 gap-2">
              {['Наличные', 'Карта', 'Безнал (р/с)'].map(m => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMethod(m)}
                  className={`py-3 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    method === m
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 rounded text-slate-300 font-medium cursor-pointer"
            >
              Отмена
            </button>
            <button
              onClick={() => onConfirm(method)}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded cursor-pointer shadow-lg shadow-emerald-600/30"
            >
              Подтвердить получение {finalTotal.toLocaleString('ru-RU')} ₽
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}