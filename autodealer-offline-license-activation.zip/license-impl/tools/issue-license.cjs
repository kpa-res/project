// Запуск: node tools/issue-license.cjs activation-request.json license.json [days]
// Храните LICENSE-PRIVATE-KEY.pem только у издателя, никогда не распространяйте с приложением.
const fs=require('node:fs'); const crypto=require('node:crypto'); const path=require('node:path');
const [,,reqPath,outPath,daysArg='365']=process.argv;
if(!reqPath||!outPath){console.error('Использование: node tools/issue-license.cjs request.json license.json [days]');process.exit(2)}
const req=JSON.parse(fs.readFileSync(reqPath,'utf8'));
if(req.format!=='autodealer-activation-request'||!req.deviceId){console.error('Некорректный запрос активации');process.exit(2)}
const days=Number(daysArg); if(!Number.isFinite(days)||days<1){console.error('Количество дней должно быть положительным');process.exit(2)}
const payload={product:'АвтоДилер',licenseId:crypto.randomUUID(),customerName:String(req.customerName||''),deviceId:req.deviceId,issuedAt:new Date().toISOString(),expiresAt:new Date(Date.now()+days*86400000).toISOString()};
const canonical=JSON.stringify(payload); const privateKey=fs.readFileSync(path.join(__dirname,'..','LICENSE-PRIVATE-KEY.pem'));
const signature=crypto.sign('RSA-SHA256',Buffer.from(canonical),privateKey).toString('base64');
fs.writeFileSync(outPath,JSON.stringify({payload,signature},null,2)); console.log('Лицензия создана:',outPath,'до',payload.expiresAt);
